/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Gate extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Gate", "./Gate/costumes/Gate.png", { x: 28, y: 48 }),
      new Costume("Gate2", "./Gate/costumes/Gate2.png", { x: 28, y: 48 }),
      new Costume("Gate3", "./Gate/costumes/Gate3.png", { x: 28, y: 48 }),
      new Costume("Gate4", "./Gate/costumes/Gate4.png", { x: 28, y: 48 }),
      new Costume("Gate5", "./Gate/costumes/Gate5.png", { x: 28, y: 48 }),
      new Costume("Gate6", "./Gate/costumes/Gate6.png", { x: 28, y: 48 }),
      new Costume("Gate7", "./Gate/costumes/Gate7.png", { x: 28, y: 48 }),
      new Costume("Gate8", "./Gate/costumes/Gate8.png", { x: 28, y: 48 }),
      new Costume("Gate9", "./Gate/costumes/Gate9.png", { x: 28, y: 48 }),
      new Costume("Gate10", "./Gate/costumes/Gate10.png", { x: 28, y: 48 }),
      new Costume("Gate11", "./Gate/costumes/Gate11.png", { x: 28, y: 48 }),
      new Costume("Gate12", "./Gate/costumes/Gate12.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("Gate", "./Gate/sounds/Gate.mp3")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Open Gate" },
        this.whenIReceiveOpenGate
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
    ];

    this.vars.x = 682;
    this.vars.y = -60;
  }

  *whenGreenFlagClicked() {
    this.effects.clear();
    this.moveAhead();
    this.visible = false;
  }

  *whenIReceiveFadeInGame() {
    this.goto(202, -60);
    this.visible = true;
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveOpenGate() {
    yield* this.startSound("Gate");
    for (let i = 0; i < 11; i++) {
      this.costumeNumber++;
      yield* this.wait(0.1);
      yield;
    }
    this.stage.vars.Progress++;
    yield* this.wait(1);
    this.stage.vars.Achievementcode = "GATE";
    this.broadcast("Unlock Achievement");
    yield* this.wait(0.5);
    this.broadcast("Normal Speech");
  }

  *whenIReceiveSetup() {
    this.goto(202, -60);
    this.costume = "Gate";
    this.vars.x = this.x + 480;
    this.vars.y = this.y;
  }
}
