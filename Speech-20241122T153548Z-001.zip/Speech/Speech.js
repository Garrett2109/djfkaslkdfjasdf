/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Speech extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Speech/costumes/costume1.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [
      new Sound("GF_1", "./Speech/sounds/GF_1.mp3"),
      new Sound("GF_2", "./Speech/sounds/GF_2.mp3"),
      new Sound("G3_1", "./Speech/sounds/G3_1.mp3"),
      new Sound("G3_2", "./Speech/sounds/G3_2.mp3"),
      new Sound("G3_3", "./Speech/sounds/G3_3.mp3"),
      new Sound("G3_4", "./Speech/sounds/G3_4.mp3"),
      new Sound("1_1", "./Speech/sounds/1_1.mp3"),
      new Sound("1_2", "./Speech/sounds/1_2.mp3"),
      new Sound("1_3", "./Speech/sounds/1_3.mp3"),
      new Sound("1_4", "./Speech/sounds/1_4.mp3"),
      new Sound("1_5", "./Speech/sounds/1_5.mp3"),
      new Sound("1_6", "./Speech/sounds/1_6.mp3"),
      new Sound("1_7", "./Speech/sounds/1_7.mp3"),
      new Sound("1_8", "./Speech/sounds/1_8.mp3"),
      new Sound("1_9", "./Speech/sounds/1_9.mp3"),
      new Sound("1_10", "./Speech/sounds/1_10.mp3"),
      new Sound("1_11", "./Speech/sounds/1_11.mp3"),
      new Sound("1_12", "./Speech/sounds/1_12.mp3"),
      new Sound("1_13", "./Speech/sounds/1_13.mp3"),
      new Sound("2_1", "./Speech/sounds/2_1.mp3"),
      new Sound("2_2", "./Speech/sounds/2_2.mp3"),
      new Sound("2_3", "./Speech/sounds/2_3.mp3"),
      new Sound("2_4", "./Speech/sounds/2_4.mp3"),
      new Sound("3_1", "./Speech/sounds/3_1.mp3"),
      new Sound("4_1", "./Speech/sounds/4_1.mp3"),
      new Sound("5_1", "./Speech/sounds/5_1.mp3"),
      new Sound("6_1", "./Speech/sounds/6_1.mp3"),
      new Sound("7_1", "./Speech/sounds/7_1.mp3"),
      new Sound("8_1", "./Speech/sounds/8_1.mp3"),
      new Sound("8_2", "./Speech/sounds/8_2.mp3"),
      new Sound("8_3", "./Speech/sounds/8_3.mp3"),
      new Sound("8_4", "./Speech/sounds/8_4.mp3"),
      new Sound("8_5", "./Speech/sounds/8_5.mp3"),
      new Sound("RR_1", "./Speech/sounds/RR_1.mp3"),
      new Sound("G2_1", "./Speech/sounds/G2_1.mp3"),
      new Sound("G2_2", "./Speech/sounds/G2_2.mp3"),
      new Sound("G4_1", "./Speech/sounds/G4_1.mp3"),
      new Sound("9_1", "./Speech/sounds/9_1.mp3"),
      new Sound("10_1", "./Speech/sounds/10_1.mp3"),
      new Sound("10_2", "./Speech/sounds/10_2.mp3"),
      new Sound("10_3", "./Speech/sounds/10_3.mp3"),
      new Sound("11_1", "./Speech/sounds/11_1.mp3"),
      new Sound("11_2", "./Speech/sounds/11_2.mp3"),
      new Sound("11_3", "./Speech/sounds/11_3.mp3"),
      new Sound("11_4", "./Speech/sounds/11_4.mp3"),
      new Sound("12_1", "./Speech/sounds/12_1.mp3"),
      new Sound("12_2", "./Speech/sounds/12_2.mp3"),
      new Sound("12_3", "./Speech/sounds/12_3.mp3"),
      new Sound("12_4", "./Speech/sounds/12_4.mp3"),
      new Sound("12_5", "./Speech/sounds/12_5.mp3"),
      new Sound("12_6", "./Speech/sounds/12_6.mp3"),
      new Sound("12_7", "./Speech/sounds/12_7.mp3"),
      new Sound("12_8", "./Speech/sounds/12_8.mp3"),
      new Sound("12_9", "./Speech/sounds/12_9.mp3"),
      new Sound("12_10", "./Speech/sounds/12_10.mp3"),
      new Sound("13_1", "./Speech/sounds/13_1.mp3"),
      new Sound("13_2", "./Speech/sounds/13_2.mp3"),
      new Sound("13_3", "./Speech/sounds/13_3.mp3"),
      new Sound("13_4", "./Speech/sounds/13_4.mp3"),
      new Sound("14_1", "./Speech/sounds/14_1.mp3"),
      new Sound("14_2", "./Speech/sounds/14_2.mp3"),
      new Sound("15_1", "./Speech/sounds/15_1.mp3"),
      new Sound("15_2", "./Speech/sounds/15_2.mp3"),
      new Sound("16_1", "./Speech/sounds/16_1.mp3"),
      new Sound("16_2", "./Speech/sounds/16_2.mp3"),
      new Sound("16_3", "./Speech/sounds/16_3.mp3"),
      new Sound("16_4", "./Speech/sounds/16_4.mp3"),
      new Sound("16_5", "./Speech/sounds/16_5.mp3"),
      new Sound("17_1", "./Speech/sounds/17_1.mp3"),
      new Sound("18_1", "./Speech/sounds/18_1.mp3"),
      new Sound("18_2", "./Speech/sounds/18_2.mp3"),
      new Sound("18_3", "./Speech/sounds/18_3.mp3"),
      new Sound("19_1", "./Speech/sounds/19_1.mp3"),
      new Sound("19_2", "./Speech/sounds/19_2.mp3"),
      new Sound("19_3", "./Speech/sounds/19_3.mp3"),
      new Sound("20_1", "./Speech/sounds/20_1.mp3"),
      new Sound("20_2", "./Speech/sounds/20_2.mp3"),
      new Sound("21_1", "./Speech/sounds/21_1.mp3"),
      new Sound("21_2", "./Speech/sounds/21_2.mp3"),
      new Sound("21_3", "./Speech/sounds/21_3.mp3"),
      new Sound("24_1", "./Speech/sounds/24_1.mp3"),
      new Sound("24_2", "./Speech/sounds/24_2.mp3"),
      new Sound("24_3", "./Speech/sounds/24_3.mp3"),
      new Sound("25_1", "./Speech/sounds/25_1.mp3"),
      new Sound("25_2", "./Speech/sounds/25_2.mp3"),
      new Sound("25_3", "./Speech/sounds/25_3.mp3"),
      new Sound("25_4", "./Speech/sounds/25_4.mp3"),
      new Sound("26_1", "./Speech/sounds/26_1.mp3"),
      new Sound("26_2", "./Speech/sounds/26_2.mp3"),
      new Sound("27_1", "./Speech/sounds/27_1.mp3"),
      new Sound("27_2", "./Speech/sounds/27_2.mp3"),
      new Sound("27_3", "./Speech/sounds/27_3.mp3"),
      new Sound("28_1", "./Speech/sounds/28_1.mp3"),
      new Sound("28_2", "./Speech/sounds/28_2.mp3"),
      new Sound("29_1", "./Speech/sounds/29_1.mp3"),
      new Sound("29_2", "./Speech/sounds/29_2.mp3"),
      new Sound("30_1", "./Speech/sounds/30_1.mp3"),
      new Sound("30_2", "./Speech/sounds/30_2.mp3"),
      new Sound("31_1", "./Speech/sounds/31_1.mp3"),
      new Sound("31_2", "./Speech/sounds/31_2.mp3"),
      new Sound("31_3", "./Speech/sounds/31_3.mp3"),
      new Sound("31_4", "./Speech/sounds/31_4.mp3"),
      new Sound("31_5", "./Speech/sounds/31_5.mp3"),
      new Sound("31_6", "./Speech/sounds/31_6.mp3"),
      new Sound("31_7", "./Speech/sounds/31_7.mp3"),
      new Sound("31_8", "./Speech/sounds/31_8.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Speak" }, this.whenIReceiveSpeak),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Stop Speech" },
        this.whenIReceiveStopSpeech
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Loading" },
        this.whenIReceiveLoading
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.soundFile = "11_4";
    this.vars.num = 106;
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.audioEffects.volume = 0;
    this.visible = false;
  }

  *whenIReceiveSpeak() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.audioEffects.volume = 100;
      this.vars.soundFile =
        this.toString(this.stage.vars.Speech) +
        ("_" + this.toString(this.sprites["Text"].vars.speechIndex));
      this.createClone();
    }
  }

  *whenIReceiveStopSpeech() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    yield* this.playSoundUntilDone(this.vars.soundFile);
    this.stage.vars.Clonecount--;
    this.deleteThisClone();
  }

  *whenIReceiveLoading() {
    this.vars.num = 0;
    this.audioEffects.pitch = -1 / 0;
    this.audioEffects.volume = 0;
    for (let i = 0; i < 106; i++) {
      this.vars.num++;
      yield* this.startSound(this.vars.num);
      yield* this.wait(0);
      yield;
    }
    this.stopAllSounds();
    this.audioEffects.clear();
  }
}
