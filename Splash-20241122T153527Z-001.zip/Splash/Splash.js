/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Splash extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Splash/costumes/costume1.svg", {
        x: 2.5263964285713882,
        y: 3.3204090648046645,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Water_On" },
        this.whenIReceiveWaterOn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Water_Off" },
        this.whenIReceiveWaterOff
      ),
    ];

    this.vars.x = 608;
    this.vars.y = -116;
    this.vars.xvel = 0;
    this.vars.yvel = 0;
    this.vars.instance = "BASE";
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.visible = false;
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0 &&
      this.toString(this.vars.instance) === "CLONE"
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *whenIReceiveSetup() {
    this.vars.x = 608;
    this.vars.y = -116;
    this.moveAhead();
    this.moveBehind(1);
    yield* this.position();
  }

  *startAsClone() {
    this.stage.vars.Clonecount++;
    this.vars.instance = "CLONE";
    this.vars.x += this.random(-12, 12);
    this.size += this.random(-10, 0) * 2;
    this.direction += this.random(0, 3) * 90;
    this.vars.xvel = this.random(-4, 4);
    this.vars.yvel = this.random(6, 10);
    for (let i = 0; i < 5; i++) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.vars.x += this.toNumber(this.vars.xvel);
      this.vars.y += this.toNumber(this.vars.yvel);
      yield* this.position();
      yield* this.wait(0.05);
      yield;
    }
    this.stage.vars.Clonecount--;
    this.deleteThisClone();
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveGameStart() {
    while (true) {
      while (
        !(
          this.toNumber(this.stage.vars.Scrollx) === 480 &&
          this.toString(this.stage.vars.Water) === "true" &&
          this.toString(this.stage.vars.WaterComplete) === "true"
        )
      ) {
        yield;
      }
      this.createClone();
      yield* this.wait(0.00001);
      yield;
    }
  }

  *whenIReceiveWaterOn() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.vars.y = 172;
      while (
        !(
          this.toNumber(this.vars.y) === -116 ||
          this.toString(this.stage.vars.Water) === "false"
        )
      ) {
        yield* this.wait(0);
        this.vars.y -= 4;
        yield* this.position();
        this.createClone();
        this.createClone();
        yield;
      }
    }
  }

  *whenIReceiveWaterOff() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }
}
