/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Hint extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Cup Hint", "./Hint/costumes/Cup Hint.png", {
        x: 204,
        y: 112,
      }),
      new Costume("Frog Hint", "./Hint/costumes/Frog Hint.png", {
        x: 204,
        y: 112,
      }),
    ];

    this.sounds = [new Sound("Screech", "./Hint/sounds/Screech.mp3")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Cup Hint" },
        this.whenIReceiveCupHint
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Frog Hint" },
        this.whenIReceiveFrogHint
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.size = 50;
    this.visible = false;
  }

  *whenIReceiveCupHint() {
    yield* this.startSound("Screech");
    this.goto(-140, -35);
    this.costume = "Cup Hint";
    this.effects.ghost = 100;
    this.moveAhead();
    this.visible = true;
    for (let i = 0; i < 5; i++) {
      this.effects.ghost -= 20;
      yield;
    }
    yield* this.wait(0.5);
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.visible = false;
    this.stage.vars.Cuphint = "FALSE";
  }

  *whenIReceiveFrogHint() {
    yield* this.startSound("Screech");
    this.goto(-30, -132);
    this.costume = "Frog Hint";
    this.effects.ghost = 100;
    this.moveAhead();
    this.visible = true;
    for (let i = 0; i < 5; i++) {
      this.effects.ghost -= 20;
      yield;
    }
    yield* this.wait(0.5);
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 2;
      yield;
    }
    this.visible = false;
    this.stage.vars.Froghint = "FALSE";
  }
}
