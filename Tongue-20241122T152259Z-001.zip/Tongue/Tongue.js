/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Tongue extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Tongue1", "./Tongue/costumes/Tongue1.svg", { x: 7, y: 9 }),
      new Costume("Tongue2", "./Tongue/costumes/Tongue2.svg", {
        x: 7,
        y: 24.999999999999886,
      }),
      new Costume("Tongue3", "./Tongue/costumes/Tongue3.svg", {
        x: 7,
        y: 40.99999999999909,
      }),
      new Costume("Tongue4", "./Tongue/costumes/Tongue4.svg", {
        x: 7,
        y: 56.999999999998636,
      }),
      new Costume("Tongue5", "./Tongue/costumes/Tongue5.svg", {
        x: 7,
        y: 72.99999999999818,
      }),
      new Costume("Tongue6", "./Tongue/costumes/Tongue6.svg", {
        x: 7,
        y: 88.99999999999773,
      }),
      new Costume("Tongue7", "./Tongue/costumes/Tongue7.svg", {
        x: 7,
        y: 104.99999999999727,
      }),
      new Costume("Tongue8", "./Tongue/costumes/Tongue8.svg", {
        x: 7,
        y: 121.12307692307402,
      }),
      new Costume("Tongue9", "./Tongue/costumes/Tongue9.svg", {
        x: 7,
        y: 136.99999999999721,
      }),
      new Costume("Tongue10", "./Tongue/costumes/Tongue10.svg", {
        x: 7,
        y: 152.99999999999733,
      }),
      new Costume("Tongue11", "./Tongue/costumes/Tongue11.svg", {
        x: 7,
        y: 168.99999999999744,
      }),
      new Costume("Tongue12", "./Tongue/costumes/Tongue12.svg", {
        x: 7,
        y: 184.99999999999756,
      }),
      new Costume("Tongue13", "./Tongue/costumes/Tongue13.svg", {
        x: 7,
        y: 200.99999999999767,
      }),
      new Costume("Tongue14", "./Tongue/costumes/Tongue14.svg", {
        x: 7,
        y: 217.12307692307468,
      }),
      new Costume("Tongue15", "./Tongue/costumes/Tongue15.svg", {
        x: 7,
        y: 233.0461488461517,
      }),
      new Costume("Tongue16", "./Tongue/costumes/Tongue16.svg", {
        x: 7,
        y: 248.999999999998,
      }),
      new Costume("Tongue17", "./Tongue/costumes/Tongue17.svg", {
        x: 7,
        y: 264.99999999999767,
      }),
      new Costume("Tongue18", "./Tongue/costumes/Tongue18.svg", {
        x: 7,
        y: 281.0000000000007,
      }),
      new Costume("Tongue19", "./Tongue/costumes/Tongue19.svg", {
        x: 7,
        y: 297.0000000000008,
      }),
      new Costume("Tongue20", "./Tongue/costumes/Tongue20.svg", {
        x: 7,
        y: 313.0256460256418,
      }),
    ];

    this.sounds = [
      new Sound("Rip", "./Tongue/sounds/Rip.wav"),
      new Sound("Rip2", "./Tongue/sounds/Rip2.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Tongue" },
        this.whenIReceiveTongue
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.RetractTongue = "FALSE";
    this.size = 80;
    this.goto(-80, -142);
    this.visible = false;
  }

  *whenIReceiveTongue() {
    if (this.compare(this.stage.vars.Progress, 14) < 0) {
      this.stage.vars.Progress = 14;
    }
    yield* this.startSound("Rip");
    this.costume = "Tongue1";
    this.visible = true;
    this.moveAhead();
    while (
      !(
        this.costumeNumber === 20 ||
        this.toString(this.stage.vars.RetractTongue) === "true"
      )
    ) {
      this.costumeNumber++;
      yield;
    }
    yield* this.startSound("Rip2");
    this.stage.vars.RetractTongue = "TRUE";
    for (let i = 0; i < this.costumeNumber - 1; i++) {
      this.costume = this.costumeNumber - 1;
      yield;
    }
    this.stage.vars.RetractTongue = "FALSE";
    this.broadcast("Reset Frog");
    this.visible = false;
  }
}
