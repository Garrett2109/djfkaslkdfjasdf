/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Rays extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Rays/costumes/costume1.svg", {
        x: 77.5659211546708,
        y: 327.3628470338559,
      }),
    ];

    this.sounds = [
      new Sound(
        "zapsplat_science_fiction_magnetic_force_field_25229",
        "./Rays/sounds/zapsplat_science_fiction_magnetic_force_field_25229.mp3"
      ),
      new Sound("HydroSwitch", "./Rays/sounds/HydroSwitch.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Button Pressed" },
        this.whenIReceiveButtonPressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End Rays" },
        this.whenIReceiveEndRays
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
    ];

    this.audioEffects.volume = 0;

    this.vars.a = 180;
    this.vars.instance = "BASE";
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.effects.ghost = 80;
    this.visible = true;
    while (true) {
      this.vars.a += 2;
      this.direction =
        90 + Math.sin(this.degToRad(this.toNumber(this.vars.a))) * 20;
      this.effects.color =
        Math.sin(this.degToRad(this.toNumber(this.vars.a))) * 25;
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.moveBehind();
    this.moveAhead(1);
    this.visible = false;
  }

  *whenIReceiveButtonPressed() {
    if (this.toString(this.vars.instance) === "BASE") {
      yield* this.broadcastAndWait("Click Guard On");
      this.broadcast("Hide Button");
      this.goto(0, -100);
      this.audioEffects.volume = 100;
      yield* this.startSound("HydroSwitch");
      yield* this.wait(1);
      yield* this.startSound(
        "zapsplat_science_fiction_magnetic_force_field_25229"
      );
      this.vars.a = -180;
      for (let i = 0; i < 8; i++) {
        this.vars.a += 45;
        this.createClone();
        yield;
      }
      this.stage.vars.Speech = 20;
      this.broadcast("Start Speaking");
      this.broadcast("Contain Glitches");
      while (!(this.compare(this.stage.vars.Glitchcount, 1) < 0)) {
        yield;
      }
      this.broadcast("End Rays");
      this.broadcast("Click Guard Off");
      this.audioEffects.volume = 0;
      this.stage.vars.Progress++;
    }
  }

  *whenIReceiveEndRays() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveGameStart() {
    yield* this.wait(2);
    this.moveAhead();
  }
}
