/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Key extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("key", "./Key/costumes/key.png", { x: 72, y: 36 }),
    ];

    this.sounds = [
      new Sound("Drop", "./Key/sounds/Drop.mp3"),
      new Sound("PickUp", "./Key/sounds/PickUp.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Key" },
        this.whenIReceiveHideKey
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Drop Visible Objects" },
        this.whenIReceiveDropVisibleObjects
      ),
    ];

    this.vars.x = 648;
    this.vars.y = -499;
    this.vars.active = "true";
    this.vars.draggingSprite = "false";
    this.vars.lastx = 4;
    this.vars.lasty = -65;
    this.vars.xvel = 0;
    this.vars.yvel = -5;
    this.vars.sparks = "FALSE";
    this.vars.falling = "FALSE";
    this.vars.touchingMaze = "false";
    this.vars.holdOffsetx = -3;
    this.vars.holdOffsety = -2;
    this.vars.keydone = "FALSE";
    this.vars.weightwarning = "FALSE";
  }

  *whenGreenFlagClicked() {
    this.size = 50;
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.moveAhead();
    this.vars.active = "true";
    this.vars.falling = "FALSE";
    this.vars.keydone = "FALSE";
    this.vars.weightwarning = "FALSE";
    this.vars.x = 648;
    this.vars.y = -499;
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.keydone) === "FALSE") {
      yield* this.position();
    }
  }

  *position() {
    if (this.toString(this.vars.draggingSprite) === "TRUE") {
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    } else {
      this.size = 400;
      this.goto(
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      );
      this.size = 50;
      this.visible = true;
    }
  }

  *whenIReceiveImpact() {
    if (this.toString(this.vars.falling) === "FALSE") {
      yield* this.wobble(2, -2);
      yield* this.wobble(-6, 0);
      yield* this.wobble(2, 2);
      yield* this.resetwobble();
    }
  }

  *wobble(x, y) {
    this.size = 400;
    this.x += this.toNumber(x);
    this.y += this.toNumber(y);
    this.size = 50;
    yield* this.wait(0.04);
  }

  *whenIReceiveGameStart() {
    while (!(this.toString(this.vars.active) === "TRUE")) {
      yield;
    }
    while (!(this.toString(this.vars.keydone) === "TRUE")) {
      while (
        !(
          this.mouse.down &&
          this.touching("mouse") &&
          this.toString(this.stage.vars.Dragging) === "FALSE" &&
          this.toString(this.stage.vars.Clickguard) === "FALSE"
        )
      ) {
        yield;
      }
      yield* this.dragAndDrop();
      yield;
    }
  }

  *dragAndDrop() {
    this.stage.vars.Dragging = "TRUE";
    this.vars.draggingSprite = "TRUE";
    this.vars.touchingMaze = "false";
    this.vars.holdOffsetx = this.x - this.mouse.x;
    this.vars.holdOffsety = this.y - this.mouse.y;
    this.vars.lastx = this.x;
    this.vars.lasty = this.y;
    this.goto(
      this.mouse.x + this.toNumber(this.vars.holdOffsetx),
      this.mouse.y + this.toNumber(this.vars.holdOffsety)
    );
    this.moveAhead();
    yield* this.checkTouchingMaze();
    if (this.toString(this.vars.touchingMaze) === "true") {
      this.goto(this.toNumber(this.vars.lastx), this.toNumber(this.vars.lasty));
      this.vars.xvel = 0;
      this.vars.yvel = 0;
      this.vars.draggingSprite = "false";
      this.stage.vars.Dragging = "false";
    } else {
      while (
        !(!this.mouse.down || this.toString(this.vars.touchingMaze) === "true")
      ) {
        this.vars.lastx = this.x;
        this.vars.lasty = this.y;
        this.goto(
          this.mouse.x + this.toNumber(this.vars.holdOffsetx),
          this.mouse.y + this.toNumber(this.vars.holdOffsety)
        );
        this.moveAhead();
        if (this.compare(Math.abs(this.x), 215) > 0) {
          this.x = (this.x / Math.abs(this.x)) * 215;
        }
        if (this.compare(Math.abs(this.y), 158) > 0) {
          this.y = (this.y / Math.abs(this.y)) * 158;
        }
        if (this.touching(this.sprites["Ground"].andClones())) {
          yield* this.groundcheck(1);
        }
        yield* this.checkTouchingMaze();
        yield;
      }
      this.vars.xvel = this.x - this.toNumber(this.vars.lastx);
      this.vars.yvel = this.y - this.toNumber(this.vars.lasty);
      if (this.toString(this.vars.touchingMaze) === "true") {
        yield* this.startSound("Drop");
        this.goto(
          this.toNumber(this.vars.lastx),
          this.toNumber(this.vars.lasty)
        );
        this.vars.xvel = 0;
        this.vars.yvel = 0;
      }
      if (this.compare(Math.abs(this.toNumber(this.vars.xvel)), 10) > 0) {
        this.vars.xvel =
          (this.toNumber(this.vars.xvel) /
            Math.abs(this.toNumber(this.vars.xvel))) *
          10;
      }
      if (this.compare(Math.abs(this.toNumber(this.vars.yvel)), 10) > 0) {
        this.vars.yvel =
          (this.toNumber(this.vars.yvel) /
            Math.abs(this.toNumber(this.vars.yvel))) *
          10;
      }
      this.stage.vars.Dragging = "FALSE";
      this.vars.draggingSprite = "FALSE";
      if (this.toString(this.stage.vars.Scrolling) === "true") {
        yield* this.sideCheck();
        this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
        this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
        while (!(this.toString(this.stage.vars.Scrolling) === "FALSE")) {
          yield;
        }
      }
    }
    yield* this.dropKey("true");
  }

  *fallAndCheck() {
    if (this.touching("edge")) {
      this.x += 0 - this.toNumber(this.vars.xvel);
    }
    this.y += this.toNumber(this.vars.yvel);
    if (this.compare(this.y, -162) < 0) {
      this.y = -162;
    }
  }

  *dropKey(sparks) {
    this.vars.sparks = sparks;
    this.vars.falling = "TRUE";
    this.vars.touchingMaze = "false";
    while (
      !(
        this.compare(this.y, -157) < 0 ||
        this.touching(this.sprites["Ground"].andClones()) ||
        this.toString(this.vars.touchingMaze) === "true"
      )
    ) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      yield* this.checkTouchingMaze();
      if (this.toString(this.vars.touchingMaze) === "true") {
        this.x += 0 - this.toNumber(this.vars.xvel);
        this.vars.xvel = 0;
        this.vars.touchingMaze = "false";
      }
      yield* this.fallAndCheck();
      yield* this.checkTouchingMaze();
      yield;
    }
    if (this.compare(this.vars.yvel, 0) > 0) {
      this.vars.yvel = 0;
      yield* this.groundcheck(-1);
      yield* this.dropKey(sparks);
    } else {
      yield* this.groundcheck(1);
    }
    if (this.compare(this.vars.yvel, -8) > 0) {
      this.vars.sparks = "FALSE";
    }
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    if (this.toString(this.vars.sparks) === "TRUE") {
      yield* this.startSound("Drop");
      this.stage.vars.sparksx.push(this.x);
      this.stage.vars.sparksy.push(this.y);
      this.stage.vars.sparkstype.push("spark");
      this.vars.sparks = "FALSE";
      this.broadcast("Impact");
    }
    if (this.touching(this.sprites["ButtonHitbox"].andClones())) {
      if (this.toString(this.vars.weightwarning) === "FALSE") {
        this.vars.weightwarning = "TRUE";
        this.stage.vars.Speech = 29;
        this.broadcast("Start Speaking");
      }
    }
    this.vars.falling = "FALSE";
  }

  *groundcheck(dir) {
    if (
      this.touching(this.sprites["Ground"].andClones()) ||
      this.touching(this.sprites["Maze"].andClones())
    ) {
      while (
        !(
          !(
            this.touching(this.sprites["Ground"].andClones()) ||
            this.touching(this.sprites["Maze"].andClones())
          ) || this.touching("edge")
        )
      ) {
        this.y += 1 * this.toNumber(dir);
      }
      if (this.touching(this.sprites["Maze"].andClones())) {
        this.warp(this.position)();
      }
    }
  }

  *whenthisspriteclicked() {
    if (this.toString(this.vars.active) === "TRUE") {
      yield* this.startSound("PickUp");
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *sideCheck() {
    if (this.touching(this.sprites["Maze"].andClones())) {
      while (!!this.touching(this.sprites["Maze"].andClones())) {
        this.x += 1;
      }
    }
  }

  *checkTouchingMaze() {
    if (this.touching(this.sprites["Maze"].andClones())) {
      this.vars.touchingMaze = "true";
    }
  }

  *whenIReceiveHideKey() {
    this.stage.vars.Dragging = "false";
    this.vars.draggingSprite = "false";
    this.vars.keydone = "TRUE";
    this.visible = false;
    /* TODO: Implement stop other scripts in sprite */ null;
    return;
  }

  *resetwobble() {
    this.size = 400;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 50;
  }

  *whenIReceiveDropVisibleObjects() {
    if (this.toString(this.vars.active) === "TRUE") {
      if (this.toString(this.vars.draggingSprite) === "FALSE") {
        if (
          this.compare(
            Math.abs(
              this.toNumber(this.vars.x) -
                this.toNumber(this.stage.vars.Scrollx)
            ),
            240
          ) < 0 &&
          this.compare(
            Math.abs(
              this.toNumber(this.vars.y) -
                this.toNumber(this.stage.vars.Scrolly)
            ),
            180
          ) < 0
        ) {
          yield* this.dropKey("FALSE");
        }
      }
    }
  }
}
