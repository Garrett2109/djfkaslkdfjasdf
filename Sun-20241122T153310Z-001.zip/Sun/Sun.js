/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sun extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sun/costumes/costume1.svg", { x: 53, y: 53 }),
      new Costume("Sun", "./Sun/costumes/Sun.svg", { x: 89, y: 89 }),
    ];

    this.sounds = [new Sound("pop", "./Sun/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Sunset" },
        this.whenIReceiveSunset
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Escape" },
        this.whenIReceiveEscape
      ),
    ];

    this.vars.x = 1440;
    this.vars.y = 1516;
  }

  *whenIReceiveSunset() {
    this.goto(0, 100);
    this.size = 50;
    this.effects.clear();
    this.effects.brightness = 20;
    yield* this.wait(3);
    for (let i = 0; i < 50; i++) {
      this.y -= 2;
      yield;
    }
    for (let i = 0; i < 150; i++) {
      this.effects.brightness -= 0.5;
      this.effects.color -= 0.25;
      this.size += 0.3;
      this.y -= 2;
      yield;
    }
    this.visible = false;
    yield* this.broadcastAndWait("CLEAR EVERYTHING");
    yield* this.wait(1);
    yield* this.broadcastAndWait("Outro");
    this.broadcast("END OF GAME");
  }

  *whenIReceiveSetup() {
    this.vars.x = 1440;
    this.vars.y = 1516;
    yield* this.position();
  }

  *whenGreenFlagClicked() {
    this.moveAhead();
    this.visible = false;
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *whenIReceiveEscape() {
    this.size = 50;
    this.effects.clear();
    yield* this.position();
  }
}
