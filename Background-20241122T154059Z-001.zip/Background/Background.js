/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Background extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Main", "./Background/costumes/Main.svg", { x: 165, y: 45 }),
      new Costume("Maze", "./Background/costumes/Maze.svg", { x: 240, y: 180 }),
      new Costume("Goat Room", "./Background/costumes/Goat Room.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Bomb Room", "./Background/costumes/Bomb Room.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Bomb Room2", "./Background/costumes/Bomb Room2.png", {
        x: 480,
        y: 360,
      }),
      new Costume("StoreRoom", "./Background/costumes/StoreRoom.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Dungeon", "./Background/costumes/Dungeon.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Chimney", "./Background/costumes/Chimney.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Chimney2", "./Background/costumes/Chimney2.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Chimney3", "./Background/costumes/Chimney3.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Chimney4", "./Background/costumes/Chimney4.png", {
        x: 480,
        y: 360,
      }),
      new Costume("Outside", "./Background/costumes/Outside.png", {
        x: 480,
        y: 360,
      }),
      new Costume("ExitRoom", "./Background/costumes/ExitRoom.png", {
        x: 480,
        y: 360,
      }),
    ];

    this.sounds = [
      new Sound("Tree Top", "./Background/sounds/Tree Top.mp3"),
      new Sound("Water", "./Background/sounds/Water.mp3"),
      new Sound("Fire", "./Background/sounds/Fire.mp3"),
      new Sound("Wind", "./Background/sounds/Wind.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Scroll Right" },
        this.whenIReceiveScrollRight
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Scroll Left" },
        this.whenIReceiveScrollLeft
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Scroll Up" },
        this.whenIReceiveScrollUp
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Scroll Down" },
        this.whenIReceiveScrollDown
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Room Sound" },
        this.whenIReceiveRoomSound
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Stop Sounds" },
        this.whenIReceiveStopSounds
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Barrel" },
        this.whenIReceiveHideBarrel
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End Fire" },
        this.whenIReceiveEndFire
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Sunset" },
        this.whenIReceiveSunset
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Escape" },
        this.whenIReceiveEscape
      ),
    ];

    this.audioEffects.volume = 50;

    this.vars.instance = "BASE";
    this.vars.x = 0;
    this.vars.y = 0;
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.audioEffects.volume = 50;
    this.size = 100;
    this.effects.clear();
    this.visible = false;
  }

  *createRooms() {
    this.warp(this.createRoomAtCostume)(480, 0, "Goat Room");
    this.warp(this.createRoomAtCostume)(960, 0, "Bomb Room");
    this.warp(this.createRoomAtCostume)(-480, 0, "Maze");
    this.warp(this.createRoomAtCostume)(960, -360, "Dungeon");
    this.warp(this.createRoomAtCostume)(480, -360, "StoreRoom");
    this.warp(this.createRoomAtCostume)(1440, -360, "ExitRoom");
    this.warp(this.createRoomAtCostume)(1440, 0, "Chimney");
    this.warp(this.createRoomAtCostume)(1440, 352, "Chimney2");
    this.warp(this.createRoomAtCostume)(1440, 704, "Chimney3");
    this.warp(this.createRoomAtCostume)(1440, 1056, "Chimney4");
    this.warp(this.createRoomAtCostume)(1440, 1416, "Outside");
  }

  *position() {
    this.size = 800;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 100;
    this.visible = true;
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *whenIReceiveScrollRight() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.Scrolling = "TRUE";
      yield* this.broadcastAndWait("Click Guard On");
      for (let i = 0; i < 30; i++) {
        this.stage.vars.Scrollx += 16;
        this.broadcast("Position Objects");
        yield;
      }
      if (this.compare(this.stage.vars.Scrollx, 480) > 0) {
        this.stage.vars.Seenbomb = "TRUE";
      }
      if (
        this.compare(this.stage.vars.Scrollx, 960) > 0 &&
        this.compare(this.stage.vars.Scrolly, 0) < 0
      ) {
        this.stage.vars.Seenballoon = "TRUE";
      }
      this.stage.vars.Scrolling = "FALSE";
      this.broadcast("Room Sound");
      this.broadcast("Click Guard Off");
    }
  }

  *whenIReceiveScrollLeft() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.Scrolling = "TRUE";
      yield* this.broadcastAndWait("Click Guard On");
      for (let i = 0; i < 30; i++) {
        this.stage.vars.Scrollx -= 16;
        this.broadcast("Position Objects");
        yield;
      }
      if (this.toNumber(this.stage.vars.Scrollx) === 0) {
        if (this.compare(this.stage.vars.Progress, 12) < 0) {
          this.stage.vars.Progress = 12;
        }
      }
      if (this.compare(this.stage.vars.Scrollx, 0) < 0) {
        this.stage.vars.Seenfire = "TRUE";
      }
      if (
        this.compare(this.stage.vars.Scrollx, 960) < 0 &&
        this.compare(this.stage.vars.Scrolly, 0) < 0
      ) {
        this.stage.vars.Seenstorage = "TRUE";
      }
      this.stage.vars.Scrolling = "FALSE";
      this.broadcast("Room Sound");
      this.broadcast("Click Guard Off");
    }
  }

  *whenIReceiveScrollUp() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.Scrolling = "TRUE";
      yield* this.broadcastAndWait("Click Guard On");
      for (let i = 0; i < 30; i++) {
        this.stage.vars.Scrolly += 12;
        this.broadcast("Position Objects");
        yield;
      }
      this.stage.vars.Scrolling = "FALSE";
      this.broadcast("Room Sound");
      this.broadcast("Click Guard Off");
    }
  }

  *whenIReceiveScrollDown() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.Scrolling = "TRUE";
      yield* this.broadcastAndWait("Click Guard On");
      for (let i = 0; i < 30; i++) {
        this.stage.vars.Scrolly -= 12;
        this.broadcast("Position Objects");
        yield;
      }
      if (this.compare(this.stage.vars.Scrolly, 0) < 0) {
        this.stage.vars.Seenmachine = "TRUE";
      }
      this.stage.vars.Scrolling = "FALSE";
      this.broadcast("Room Sound");
      this.broadcast("Click Guard Off");
    }
  }

  *startAsClone() {
    this.vars.instance = this.costume.name;
    this.stage.vars.Clonecount++;
    yield* this.position();
  }

  *whenIReceiveFadeInGame() {
    this.stage.vars.Scrolling = "FALSE";
    this.stage.vars.Scrollx = 480;
    this.stage.vars.Scrolly = 0;
    this.stage.vars.Seenfire = "FALSE";
    this.stage.vars.Seenbomb = "FALSE";
    this.stage.vars.Seenmachine = "FALSE";
    this.stage.vars.Seenstorage = "FALSE";
    this.stage.vars.Seenballoon = "FALSE";
    this.goto(0, 0);
    this.moveBehind();
    this.vars.instance = "CLONE";
    yield* this.createRooms();
    this.vars.x = 0;
    this.vars.y = 0;
    this.costume = "Main";
    this.vars.instance = "BASE";
  }

  *wobble(x, y) {
    this.size = 800;
    this.x += this.toNumber(x);
    this.y += this.toNumber(y);
    this.size = 100;
    yield* this.wait(0.04);
  }

  *whenIReceiveImpact() {
    yield* this.wobble(2, -2);
    yield* this.wobble(-6, 0);
    yield* this.wobble(2, 2);
    yield* this.resetwobble();
  }

  *whenIReceiveGameStart() {
    yield* this.position();
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
    if (!(this.toString(this.vars.instance) === "BASE")) {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveRoomSound() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stopAllSounds();
      if (
        this.toNumber(this.stage.vars.Scrollx) === 480 &&
        this.toNumber(this.stage.vars.Scrolly) === 0
      ) {
        this.audioEffects.volume = 50;
        while (true) {
          if (this.toString(this.stage.vars.Water) === "true") {
            yield* this.playSoundUntilDone("Water");
          } else {
            null;
          }
          yield;
        }
      }
      if (this.toNumber(this.stage.vars.Scrollx) === -480) {
        if (
          this.toString(this.sprites["Pixelfire"].vars.firedone) === "FALSE"
        ) {
          this.audioEffects.volume = 100;
          while (true) {
            yield* this.playSoundUntilDone("Fire");
            yield;
          }
        }
      }
      if (this.compare(this.stage.vars.Scrolly, 0) < 0) {
        this.audioEffects.volume =
          25 + (this.toNumber(this.stage.vars.Scrollx) / 480) * 75;
        while (true) {
          yield* this.playSoundUntilDone("Wind");
          yield;
        }
      }
      if (
        this.toNumber(this.stage.vars.Scrolly) === 0 &&
        this.toNumber(this.stage.vars.Scrollx) === 960
      ) {
        if (this.compare(this.stage.vars.Progress, 17) > 0) {
          this.audioEffects.volume = 25;
          while (true) {
            yield* this.playSoundUntilDone("Wind");
            yield;
          }
        }
      }
    }
  }

  *whenIReceiveStopSounds() {
    for (let i = 0; i < 50; i++) {
      this.audioEffects.volume -= 1;
      yield;
    }
    /* TODO: Implement stop other scripts in sprite */ null;
    this.stopAllSounds();
    this.audioEffects.volume = 50;
  }

  *whenIReceiveHideBarrel() {
    if (this.costume.name === "Bomb Room") {
      this.costumeNumber++;
    }
  }

  *whenIReceiveEndFire() {
    if (this.toString(this.vars.instance) === "BASE") {
      if (this.toNumber(this.stage.vars.Scrollx) === -480) {
        this.audioEffects.volume = 0;
      }
    }
  }

  *whenIReceiveSunset() {
    if (this.costume.name === "Outside") {
      this.effects.clear();
      yield* this.wait(3);
      for (let i = 0; i < 200; i++) {
        this.effects.color += 0.5;
        this.effects.brightness -= 0.5;
        yield;
      }
    }
  }

  *whenIReceiveEscape() {
    if (this.toString(this.vars.instance) === "BASE") {
      /* TODO: Implement stop other scripts in sprite */ null;
      this.audioEffects.volume = 0;
      while (!(this.compare(this.stage.vars.Scrolly, 0) > 0)) {
        yield;
      }
      this.audioEffects.volume = 100;
      yield* this.startSound("Tree Top");
    } else {
      if (this.costume.name === "Outside") {
        this.effects.clear();
      }
    }
  }

  *createRoomAtCostume(x, y, costume) {
    this.vars.x = x;
    this.vars.y = y;
    this.costume = costume;
    this.createClone();
  }

  *resetwobble() {
    this.size = 800;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 100;
  }
}
