/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Gauge extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Gauge", "./Gauge/costumes/Gauge.svg", {
        x: 99.24677419354839,
        y: 36.42258064516133,
      }),
      new Costume("GaugeDot", "./Gauge/costumes/GaugeDot.png", { x: 5, y: 5 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Gauge" }, this.whenIReceiveGauge),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Remove Text" },
        this.whenIReceiveRemoveText
      ),
    ];

    this.vars.pos = 68;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveGauge() {
    this.clearPen();
    this.goto(0, 0);
    this.costume = "Gauge";
    this.visible = true;
    yield* this.wait(0.5);
    this.vars.pos = -62;
    for (let i = 0; i < 26; i++) {
      yield* this.stampdot();
      yield* this.wait(this.random(0.05, 0.2));
      yield;
    }
    yield* this.wait(0.5);
  }

  *stampdot() {
    this.goto(this.toNumber(this.vars.pos), -1);
    this.costume = "GaugeDot";
    this.stamp();
    this.goto(0, 0);
    this.costume = "Gauge";
    this.vars.pos += 5;
  }

  *whenIReceiveRemoveText() {
    this.clearPen();
    this.visible = false;
  }
}
