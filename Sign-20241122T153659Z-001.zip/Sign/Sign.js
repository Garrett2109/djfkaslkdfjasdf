/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sign extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Sign", "./Sign/costumes/Sign.svg", {
        x: 345.0416666666667,
        y: 162.5416666666667,
      }),
      new Costume("Drop", "./Sign/costumes/Drop.svg", { x: 160.75, y: 100.25 }),
      new Costume("Drop2", "./Sign/costumes/Drop2.svg", {
        x: 160.75,
        y: 100.25000000000003,
      }),
      new Costume("Drop3", "./Sign/costumes/Drop3.svg", {
        x: 160.75,
        y: 100.25000000000003,
      }),
      new Costume("Drop4", "./Sign/costumes/Drop4.svg", {
        x: 160.75,
        y: 100.25000000000003,
      }),
      new Costume("Drop5", "./Sign/costumes/Drop5.svg", {
        x: 160.75,
        y: 100.25,
      }),
      new Costume("Drop6", "./Sign/costumes/Drop6.svg", {
        x: 160.75,
        y: 100.25,
      }),
      new Costume("Drop7", "./Sign/costumes/Drop7.svg", {
        x: 160.75,
        y: 100.25,
      }),
      new Costume("Drop8", "./Sign/costumes/Drop8.svg", {
        x: 160.75,
        y: 100.25,
      }),
    ];

    this.sounds = [
      new Sound("BoxDrop", "./Sign/sounds/BoxDrop.mp3"),
      new Sound("PickUp", "./Sign/sounds/PickUp.mp3"),
      new Sound("Smash", "./Sign/sounds/Smash.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Straighten" },
        this.whenIReceiveStraighten
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart2
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
    ];

    this.vars.draggingSprite = "false";
    this.vars.baseDir = -37.97879528469704;
    this.vars.mouseDir = 60.00131846047148;
    this.vars.mouseOldDir = 60.00131846047148;
    this.vars.x = 560;
    this.vars.y = -75.95113341427309;
    this.vars.hanging = "false";
    this.vars.swings = 5;
    this.vars.sparks = "TRUE";
    this.vars.falling = "FALSE";
    this.vars.yvel = -13;
    this.vars.xvel = -2.0000000000000004;
    this.vars.lastx = 80;
    this.vars.sideImpact = "true";
    this.vars.slide = "true";
    this.vars.signdone = "true";
    this.vars.initdir = -37.97879528469704;
  }

  *applyFriction() {
    this.stage.vars.rotation =
      this.toNumber(this.stage.vars.rotation) *
      (1 - this.toNumber(this.stage.vars.friction));
  }

  *applyGravity() {
    this.stage.vars.angle = Math.abs(this.direction);
    if (this.compare(this.stage.vars.angle, 90) > 0) {
      this.stage.vars.angle = Math.abs(
        this.toNumber(this.stage.vars.angle) - 180
      );
    }
    this.stage.vars.rotationChange = this.toNumber(this.stage.vars.angle) / 10;
    if (this.compare(this.direction, 0) < 0) {
      this.stage.vars.rotationChange =
        this.toNumber(this.stage.vars.rotationChange) * -1;
    }
    this.stage.vars.rotation += this.toNumber(this.stage.vars.rotationChange);
  }

  *moveSprite() {
    this.broadcast("Click Guard On");
    if (this.compare(Math.abs(this.direction), 10) > 0) {
      this.vars.swings++;
    }
    this.vars.initdir = this.direction;
    while (
      !(
        (Math.round(this.toNumber(this.stage.vars.rotation)) === 0 &&
          Math.round(this.direction) === 0) ||
        (this.toNumber(this.vars.swings) === 5 &&
          this.compare(this.direction / this.toNumber(this.vars.initdir), 0) <
            0)
      )
    ) {
      yield* this.applyGravity();
      yield* this.applyFriction();
      this.direction = this.direction - this.toNumber(this.stage.vars.rotation);
      yield;
    }
    if (
      Math.round(this.toNumber(this.stage.vars.rotation)) === 0 &&
      Math.round(this.direction) === 0
    ) {
      this.direction = 0;
    } else {
      this.stage.vars.sparksx.push(this.x);
      this.stage.vars.sparksy.push(this.y);
      this.stage.vars.sparkstype.push("spark");
      this.vars.hanging = "false";
      this.vars.xvel = -5 * (this.direction / Math.abs(this.direction));
      this.vars.yvel = 0;
      this.costume = "Drop";
      this.direction += 90;
      this.direction += 90;
      this.move(120);
      this.direction -= 90;
      this.broadcast("Straighten");
      yield* this.startSound("Smash");
      yield* this.dropSign("TRUE");
      this.stage.vars.Progress++;
    }
    this.broadcast("Click Guard Off");
  }

  *whenGreenFlagClicked() {
    this.size = 40;
    this.visible = false;
  }

  *whenIReceiveFadeInGame() {
    this.goto(0, 132);
    this.visible = true;
  }

  *dragAndDrop() {
    if (this.toString(this.vars.hanging) === "true") {
      this.vars.draggingSprite = "TRUE";
      this.stage.vars.Dragging = "TRUE";
      this.stage.vars.rotation = 0;
      this.vars.baseDir = this.direction;
      this.direction = this.radToScratch(
        Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
      );
      this.direction -= 90;
      this.vars.mouseDir = this.direction;
      if (this.compare(this.vars.mouseDir, 0) < 0) {
        this.vars.mouseDir = this.toNumber(this.vars.mouseDir) + 360;
      }
      this.direction = this.toNumber(this.vars.baseDir);
      this.vars.mouseOldDir = this.vars.mouseDir;
      while (!(!this.mouse.down || !this.touching("mouse"))) {
        this.vars.baseDir = this.direction;
        this.direction = this.radToScratch(
          Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
        );
        this.direction -= 90;
        this.vars.mouseDir = this.direction;
        if (this.compare(this.vars.mouseDir, 0) < 0) {
          this.vars.mouseDir = this.toNumber(this.vars.mouseDir) + 360;
        }
        this.vars.baseDir +=
          this.toNumber(this.vars.mouseDir) -
          this.toNumber(this.vars.mouseOldDir);
        this.vars.mouseOldDir = this.vars.mouseDir;
        this.direction = this.toNumber(this.vars.baseDir);
        if (this.compare(Math.abs(this.toNumber(this.vars.baseDir)), 60) > 0) {
          this.direction =
            (Math.abs(this.toNumber(this.vars.baseDir)) /
              this.toNumber(this.vars.baseDir)) *
            60;
        }
        yield;
      }
      this.vars.draggingSprite = "FALSE";
      this.stage.vars.Dragging = "FALSE";
      yield* this.moveSprite();
    } else {
      this.vars.draggingSprite = "TRUE";
      this.stage.vars.Dragging = "TRUE";
      while (
        !(
          !this.mouse.down ||
          this.toString(this.vars.draggingSprite) === "FALSE"
        )
      ) {
        this.vars.lastx = this.x;
        this.x = this.mouse.x;
        this.vars.sideImpact = "false";
        yield* this.checkSideImpact();
        if (this.toString(this.vars.sideImpact) === "true") {
          this.stage.vars.Dragging = "FALSE";
          this.vars.draggingSprite = "FALSE";
          this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
          yield* this.startSound("BoxDrop");
          if (this.compare(this.stage.vars.Progress, 7) < 0) {
            this.stage.vars.Progress++;
            this.costumeNumber++;
            if (this.toNumber(this.stage.vars.Progress) === 2) {
              yield* this.createLetterAt("O", -13, -2);
            }
            if (this.toNumber(this.stage.vars.Progress) === 3) {
              yield* this.createLetterAt("U", 2, 22);
            }
            if (this.toNumber(this.stage.vars.Progress) === 4) {
              yield* this.createLetterAt("O", -22, 23);
            }
            if (this.toNumber(this.stage.vars.Progress) === 5) {
              yield* this.createLetterAt("R", -27, -32);
            }
            if (this.toNumber(this.stage.vars.Progress) === 6) {
              yield* this.createLetterAt("E", 32, -33);
            }
            if (this.toNumber(this.stage.vars.Progress) === 7) {
              null;
            }
            this.broadcast("Spawn Letters");
            this.broadcast("Drop Speaker");
          }
          yield* this.broadcastAndWait("Impact");
        }
        if (this.compare(Math.abs(this.x), 215) > 0) {
          this.x = (this.x / Math.abs(this.x)) * 215;
        }
        yield;
      }
      this.vars.draggingSprite = "FALSE";
      this.stage.vars.Dragging = "FALSE";
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    }
  }

  *whenIReceiveGameStart() {
    while (true) {
      while (
        !(
          this.mouse.down &&
          this.touching("mouse") &&
          this.toString(this.stage.vars.Dragging) === "FALSE" &&
          this.toString(this.stage.vars.Clickguard) === "FALSE" &&
          this.toString(this.stage.vars.Showingsettings) === "FALSE"
        )
      ) {
        yield;
      }
      yield* this.dragAndDrop();
      yield;
    }
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *dropSign(sparks) {
    this.vars.sparks = sparks;
    this.vars.falling = "TRUE";
    while (
      !(
        this.compare(this.y, -154) < 0 ||
        this.touching(this.sprites["Ground"].andClones())
      )
    ) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      yield* this.fallAndCheck();
      yield;
    }
    yield* this.groundcheck();
    if (this.compare(this.stage.vars.Scrolly, 0) > 0) {
      this.visible = false;
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y;
      this.vars.falling = "FALSE";
    } else {
      if (this.compare(this.vars.yvel, -8) > 0) {
        this.vars.sparks = "FALSE";
      }
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
      this.vars.falling = "FALSE";
      if (this.costume.name === "Drop") {
        this.costume = "Drop2";
        yield* this.createLetterAt("T", 33, 28);
        yield* this.startSound("BoxDrop");
        this.broadcast("Spawn Letters");
      }
      this.vars.xvel = 0;
      yield* this.broadcastAndWait("Impact");
    }
  }

  *whenIReceiveStraighten() {
    while (!(Math.round(this.direction) === 90)) {
      if (this.compare(this.direction, 90) > 0) {
        this.direction -= 1;
      } else {
        this.direction += 1;
      }
      yield;
    }
    if (this.toString(this.vars.falling) === "false") {
      yield* this.dropSign("false");
    }
  }

  *fallAndCheck() {
    if (this.touching("edge")) {
      this.x += 0 - this.toNumber(this.vars.xvel);
    }
    this.y += this.toNumber(this.vars.yvel);
    if (this.compare(this.y, -155) < 0) {
      this.y = -155;
    }
  }

  *groundcheck() {
    if (this.touching(this.sprites["Ground"].andClones())) {
      while (!!this.touching(this.sprites["Ground"].andClones())) {
        this.y += 1;
      }
    }
  }

  *whenthisspriteclicked() {
    yield* this.startSound("PickUp");
  }

  *checkSideImpact() {
    if (this.toString(this.vars.sideImpact) === "false") {
      if (this.touching(this.sprites["Ground"].andClones())) {
        if (this.compare(this.x, this.vars.lastx) > 0) {
          while (!!this.touching(this.sprites["Ground"].andClones())) {
            this.x -= 1;
          }
        } else {
          while (!!this.touching(this.sprites["Ground"].andClones())) {
            this.x += 1;
          }
        }
        if (
          this.compare(Math.abs(this.x - this.toNumber(this.vars.lastx)), 1) > 0
        ) {
          this.vars.sideImpact = "true";
        }
        this.vars.lastx = this.x;
      }
    }
  }

  *position() {
    if (this.toString(this.vars.draggingSprite) === "TRUE") {
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    } else {
      this.goto(
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      );
      if (
        this.compare(
          this.x,
          this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
        ) === 0 &&
        this.compare(
          this.y,
          this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
        ) === 0
      ) {
        this.visible = true;
      } else {
        this.visible = false;
      }
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.signdone) === "FALSE") {
      yield* this.position();
    }
  }

  *createLetterAt(type, x, y) {
    this.stage.vars.lettertype.push(type);
    this.stage.vars.letterx.push(this.x + this.toNumber(x));
    this.stage.vars.lettery.push(this.y + this.toNumber(y));
  }

  *whenIReceiveGameStart2() {
    while (
      !(
        this.touching(this.sprites["Puddle"].andClones()) &&
        this.compare(this.stage.vars.Progress, 7) > 0
      )
    ) {
      yield;
    }
    this.vars.draggingSprite = "true";
    this.vars.slide = "true";
    this.vars.xvel = 0;
    while (true) {
      this.stage.vars.sparksx.push(this.x - 50 + this.random(0, 100));
      this.stage.vars.sparksy.push(this.y - 25);
      this.stage.vars.sparkstype.push("spark");
      if (this.touching(this.sprites["Puddle"].andClones())) {
        this.y += 1;
        if (this.compare(this.vars.xvel, -2) > 0) {
          this.vars.xvel -= 0.1;
        }
      }
      this.size = 100;
      this.x += this.toNumber(this.vars.xvel);
      this.size = 40;
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.size = 100;
        this.x += 0 - this.toNumber(this.vars.xvel);
        this.size = 40;
      }
      if (this.compare(this.x, -300) < 0) {
        this.vars.draggingSprite = "false";
        this.vars.signdone = "true";
        this.visible = false;
        yield* this.startSound("Smash");
        this.stage.vars.Progress++;
        /* TODO: Implement stop other scripts in sprite */ null;
        return;
      }
      yield;
    }
  }

  *whenIReceiveSetup() {
    this.goto(0, 132);
    this.direction = 0;
    this.vars.x = this.x + 480;
    this.vars.y = this.y;
    this.vars.draggingSprite = "false";
    this.vars.hanging = "true";
    this.vars.slide = "false";
    this.vars.swings = 0;
    this.vars.slide = "false";
    this.vars.signdone = "false";
    this.stage.vars.rotation = 0;
    this.stage.vars.friction = 0.15;
    this.costume = "Sign";
    this.effects.clear();
  }
}
