/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Barrel extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Barrel2", "./Barrel/costumes/Barrel2.svg", {
        x: 77.8810975609756,
        y: 59.45121951219511,
      }),
      new Costume("Barrels", "./Barrel/costumes/Barrels.svg", {
        x: 52,
        y: 53.3953096273292,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Barrel" },
        this.whenIReceiveHideBarrel
      ),
    ];

    this.vars.x = 960;
    this.vars.y = -77;
  }

  *whenGreenFlagClicked() {
    this.goto(0, -77);
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.x = 960;
    this.vars.y = -77;
    yield* this.position();
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveHideBarrel() {
    this.vars.x = 99999;
    yield* this.position();
  }
}
