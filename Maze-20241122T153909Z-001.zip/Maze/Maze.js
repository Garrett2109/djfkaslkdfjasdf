/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Maze extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Maze-Hitbox", "./Maze/costumes/Maze-Hitbox.svg", {
        x: 240,
        y: 180,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.x = -480;
    this.vars.y = 0;
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = false;
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveFadeInGame() {
    this.vars.x = -480;
    this.vars.y = 0;
    this.moveAhead();
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
