/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Checkbox extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Off", "./Checkbox/costumes/Off.svg", {
        x: 99.84985,
        y: 90.84084,
      }),
      new Costume("On", "./Checkbox/costumes/On.svg", {
        x: 99.84984984984985,
        y: 90.84084084084083,
      }),
    ];

    this.sounds = [
      new Sound(
        "multimedia-button-click-7-sound-effect-57128907",
        "./Checkbox/sounds/multimedia-button-click-7-sound-effect-57128907.wav"
      ),
      new Sound("RickRoll", "./Checkbox/sounds/RickRoll.mp3"),
      new Sound("Zip", "./Checkbox/sounds/Zip.mp3"),
      new Sound("SpawnTree", "./Checkbox/sounds/SpawnTree.mp3"),
      new Sound("PickupWater", "./Checkbox/sounds/PickupWater.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Render Setting Text" },
        this.whenIReceiveRenderSettingText
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Settings" },
        this.whenIReceiveHideSettings
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Monitor Mouse" },
        this.whenIReceiveMonitorMouse
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "RickRoll" },
        this.whenIReceiveRickroll
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Griffpatch" },
        this.whenIReceiveGriffpatch
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Normal Speech" },
        this.whenIReceiveNormalSpeech
      ),
      new Trigger(Trigger.BROADCAST, { name: "Water" }, this.whenIReceiveWater),
    ];

    this.vars.instance = "BASE";
    this.vars.buttontype = "Water";
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.size = 35;
    this.visible = false;
    while (true) {
      yield* this.broadcastAndWait("Monitor Mouse");
      yield;
    }
  }

  *whenthisspriteclicked() {
    this.broadcast("Click Guard On");
    if (this.toString(this.vars.buttontype) === "Griffpatch") {
      this.stage.vars.Griffpatch =
        this.toString(this.stage.vars.Griffpatch) === "FALSE";
      this.broadcast("Griffpatch");
    }
    if (this.toString(this.vars.buttontype) === "Water") {
      this.stage.vars.Water = this.toString(this.stage.vars.Water) === "FALSE";
      this.broadcast("Water");
    }
    if (this.toString(this.vars.buttontype) === "Music") {
      this.stage.vars.Music = this.toString(this.stage.vars.Music) === "FALSE";
      this.broadcast("RickRoll");
    }
    yield* this.startSound("multimedia-button-click-7-sound-effect-57128907");
    yield* this.nextcostume();
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.effects.clear();
    this.effects.brightness = 0;
    this.moveAhead();
    this.visible = true;
  }

  *createbuttons() {
    this.vars.buttontype = "Griffpatch";
    this.goto(0, 15);
    if (this.toString(this.stage.vars.Griffpatch) === "TRUE") {
      this.costume = "On";
    } else {
      this.costume = "Off";
    }
    this.createClone();
    this.vars.buttontype = "Music";
    this.goto(0, -55);
    if (this.toString(this.stage.vars.Music) === "TRUE") {
      this.costume = "On";
    } else {
      this.costume = "Off";
    }
    this.createClone();
    this.vars.buttontype = "Water";
    this.goto(0, -125);
    if (this.toString(this.stage.vars.Water) === "TRUE") {
      this.costume = "On";
    } else {
      this.costume = "Off";
    }
    this.createClone();
  }

  *whenIReceiveRenderSettingText() {
    yield* this.createbuttons();
  }

  *whenIReceiveHideSettings() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveMonitorMouse() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.moveAhead();
      this.stage.vars.Mousetouchingcheckbox = 0;
    } else {
      if (this.touching("mouse")) {
        this.stage.vars.Mousetouchingcheckbox++;
      }
    }
  }

  *nextcostume() {
    if (this.letterOf(this.costume.name, 1) === "f") {
      this.costume = "On";
    } else {
      this.costume = "Off";
    }
  }

  *whenIReceiveSetup() {
    this.stage.vars.Music = "false";
    this.stage.vars.Griffpatch = "false";
    this.stage.vars.Water = "false";
  }

  *whenIReceiveRickroll() {
    if (this.toString(this.vars.buttontype) === "Music") {
      if (this.toString(this.stage.vars.Music) === "TRUE") {
        this.audioEffects.volume = 50;
        yield* this.playSoundUntilDone("RickRoll");
        this.audioEffects.volume = 100;
        yield* this.startSound("Zip");
        this.stage.vars.Music = "FALSE";
        yield* this.nextcostume();
        this.broadcast("Stop Speaking");
        yield* this.broadcastAndWait("Remove Text");
        this.stage.vars.Speech = "RR";
        this.broadcast("Start Speaking");
      } else {
        this.stopAllSounds();
      }
      this.broadcast("Click Guard Off");
    }
  }

  *whenIReceiveGriffpatch() {
    if (this.toString(this.vars.buttontype) === "Griffpatch") {
      if (this.toString(this.stage.vars.Griffpatch) === "TRUE") {
        this.broadcast("Stop Speaking");
        yield* this.broadcastAndWait("Remove Text");
        if (this.toNumber(this.stage.vars.Progress) === 16) {
          this.stage.vars.Speech = "G3";
        } else {
          this.stage.vars.Speech = "GF";
        }
        this.broadcast("Start Speaking");
      }
    }
  }

  *whenIReceiveNormalSpeech() {
    if (this.toString(this.vars.buttontype) === "Griffpatch") {
      this.stage.vars.Griffpatch = "FALSE";
      yield* this.startSound("multimedia-button-click-7-sound-effect-57128907");
      yield* this.nextcostume();
      this.broadcast("Stop Speaking");
      yield* this.broadcastAndWait("Remove Text");
      if (this.toNumber(this.stage.vars.Progress) === 17) {
        this.stage.vars.Speech = "G4";
      } else {
        this.stage.vars.Speech = "G2";
      }
      this.broadcast("Start Speaking");
      this.broadcast("Click Guard Off");
    }
  }

  *whenIReceiveWater() {
    if (this.toString(this.vars.buttontype) === "Water") {
      if (this.toString(this.stage.vars.Water) === "true") {
        yield* this.startSound("PickupWater");
        yield* this.wait(1);
        if (this.compare(this.stage.vars.Progress, 9) < 0) {
          this.stage.vars.Progress = 9;
          this.broadcast("Hide Settings");
        }
        this.broadcast("Water_On");
      } else {
        this.stage.vars.WaterComplete = "false";
        this.broadcast("Water_Off");
      }
      if (this.compare(this.stage.vars.Progress, 9) > 0) {
        this.broadcast("Click Guard Off");
      }
      this.broadcast("Room Sound");
    }
  }
}
