/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Glitch extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Glitch", "./Glitch/costumes/Glitch.png", { x: 64, y: 64 }),
      new Costume("Glitch2", "./Glitch/costumes/Glitch2.png", { x: 64, y: 64 }),
      new Costume("Glitch3", "./Glitch/costumes/Glitch3.png", { x: 64, y: 64 }),
      new Costume("Glitch4", "./Glitch/costumes/Glitch4.png", { x: 64, y: 64 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "DELETE ALL CLONES" },
        this.whenIReceiveDeleteAllClones
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Spawn Glitches" },
        this.whenIReceiveSpawnGlitches
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Stop Spawning" },
        this.whenIReceiveStopSpawning
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Contain Glitches" },
        this.whenIReceiveContainGlitches
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.x = 0;
    this.vars.y = 0;
    this.vars.counter = 0;
    this.vars.pos = 39;
    this.vars.moving = 0;
    this.vars.gotglitch = [
      97, 18, 2, 71, 93, 125, 140, 42, 155, 79, 119, 46, 103, 131, 54, 160, 23,
      112, 100, 116, 34, 44, 84, 28, 102, 121, 59, 68, 118, 33, 6, 159, 5, 87,
      31, 123, 26, 74, 122, 88, 92, 13, 27, 61, 164, 136, 62, 60, 9, 39,
    ];
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.stage.vars.Glitchcount = 0;
    this.size = 50;
    this.visible = false;
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.vars.moving = "false";
    this.vars.x =
      -224 +
      Math.floor((this.toNumber(this.vars.pos) - 1) / 11) * 32 +
      this.toNumber(this.stage.vars.Scrollx);
    this.vars.y =
      -156 +
      ((this.toNumber(this.vars.pos) - 1) % 11) * 32 +
      this.toNumber(this.stage.vars.Scrolly);
    yield* this.position();
    this.costume = this.random(1, 4);
    this.visible = true;
    if (this.touching(this.sprites["Arrow"].andClones())) {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
    this.stage.vars.Glitchcount++;
    this.effects.clear();
    this.vars.counter = this.random(1, 10);
    while (true) {
      while (!!(this.toNumber(this.stage.vars.Scrollx) === 0)) {
        yield;
      }
      this.vars.counter++;
      if (this.toString(this.vars.moving) === "false") {
        this.effects.ghost =
          25 -
          Math.sin(this.degToRad(this.toNumber(this.vars.counter) * 10)) * 25;
      }
      this.effects.brightness =
        -25 -
        Math.sin(this.degToRad(this.toNumber(this.vars.counter) * 20)) * 25;
      this.costumeNumber++;
      yield* this.wait(0.1);
      yield;
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.position();
    }
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveDeleteAllClones() {
    yield* this.deleteGlitch();
  }

  *whenIReceiveSpawnGlitches() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.vars.gotglitch = [];
      for (let i = 0; i < 50; i++) {
        yield* this.makeGlitch();
        yield* this.wait(this.random(0.05, 0.1));
        yield;
      }
      this.stage.vars.Spawning = "FALSE";
    }
  }

  *makeGlitch() {
    this.vars.pos = this.random(1, 165);
    while (!!this.arrayIncludes(this.vars.gotglitch, this.vars.pos)) {
      this.vars.pos = this.random(1, 165);
    }
    this.vars.gotglitch.push(this.vars.pos);
    this.createClone();
  }

  *whenIReceiveClearEverything() {
    yield* this.deleteGlitch();
  }

  *deleteGlitch() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Glitchcount--;
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveStopSpawning() {
    if (this.toString(this.vars.instance) === "BASE") {
      /* TODO: Implement stop other scripts in sprite */ null;
    }
  }

  *whenIReceiveContainGlitches() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.vars.moving = "true";
      yield* this.wait(0);
      this.effects.ghost = 0;
      while (true) {
        if (this.compare(this.vars.y, -180) < 0) {
          this.direction = this.radToScratch(
            Math.atan2(
              this.sprites["Rays"].y - this.y,
              this.sprites["Rays"].x - this.x
            )
          );
          this.move(2);
          this.effects.ghost += 1;
          if (this.compare(this.y, -75) < 0) {
            yield* this.deleteGlitch();
          }
        } else {
          this.vars.y -= 2;
          yield* this.position();
        }
        yield;
      }
    }
  }

  *whenIReceiveGameStart() {
    yield* this.wait(1);
    this.moveAhead();
  }
}
