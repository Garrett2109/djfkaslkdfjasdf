/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Text extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("A", "./Text/costumes/A.png", { x: 20, y: 20 }),
      new Costume("B", "./Text/costumes/B.png", { x: 20, y: 20 }),
      new Costume("C", "./Text/costumes/C.png", { x: 20, y: 20 }),
      new Costume("D", "./Text/costumes/D.png", { x: 20, y: 20 }),
      new Costume("E", "./Text/costumes/E.png", { x: 20, y: 20 }),
      new Costume("F", "./Text/costumes/F.png", { x: 20, y: 20 }),
      new Costume("G", "./Text/costumes/G.png", { x: 20, y: 20 }),
      new Costume("H", "./Text/costumes/H.png", { x: 20, y: 20 }),
      new Costume("I", "./Text/costumes/I.png", { x: 20, y: 20 }),
      new Costume("J", "./Text/costumes/J.png", { x: 20, y: 20 }),
      new Costume("K", "./Text/costumes/K.png", { x: 20, y: 20 }),
      new Costume("L", "./Text/costumes/L.png", { x: 20, y: 20 }),
      new Costume("M", "./Text/costumes/M.png", { x: 20, y: 20 }),
      new Costume("N", "./Text/costumes/N.png", { x: 20, y: 20 }),
      new Costume("O", "./Text/costumes/O.png", { x: 20, y: 20 }),
      new Costume("P", "./Text/costumes/P.png", { x: 20, y: 20 }),
      new Costume("Q", "./Text/costumes/Q.png", { x: 20, y: 20 }),
      new Costume("R", "./Text/costumes/R.png", { x: 20, y: 20 }),
      new Costume("S", "./Text/costumes/S.png", { x: 20, y: 20 }),
      new Costume("T", "./Text/costumes/T.png", { x: 20, y: 20 }),
      new Costume("U", "./Text/costumes/U.png", { x: 20, y: 20 }),
      new Costume("V", "./Text/costumes/V.png", { x: 20, y: 20 }),
      new Costume("W", "./Text/costumes/W.png", { x: 20, y: 20 }),
      new Costume("X", "./Text/costumes/X.png", { x: 20, y: 20 }),
      new Costume("Y", "./Text/costumes/Y.png", { x: 20, y: 20 }),
      new Costume("Z", "./Text/costumes/Z.png", { x: 20, y: 20 }),
      new Costume("0", "./Text/costumes/0.png", { x: 20, y: 20 }),
      new Costume("1", "./Text/costumes/1.png", { x: 20, y: 20 }),
      new Costume("2", "./Text/costumes/2.png", { x: 20, y: 20 }),
      new Costume("3", "./Text/costumes/3.png", { x: 20, y: 20 }),
      new Costume("4", "./Text/costumes/4.png", { x: 20, y: 20 }),
      new Costume("5", "./Text/costumes/5.png", { x: 20, y: 20 }),
      new Costume("6", "./Text/costumes/6.png", { x: 20, y: 20 }),
      new Costume("7", "./Text/costumes/7.png", { x: 20, y: 20 }),
      new Costume("8", "./Text/costumes/8.png", { x: 20, y: 20 }),
      new Costume("9", "./Text/costumes/9.png", { x: 20, y: 20 }),
      new Costume("_", "./Text/costumes/_.png", { x: 20, y: -12 }),
      new Costume("-", "./Text/costumes/-.png", { x: 12, y: 4 }),
      new Costume(".", "./Text/costumes/..png", { x: 20, y: 20 }),
      new Costume(",", "./Text/costumes/,.png", { x: 20, y: 20 }),
      new Costume("'", "./Text/costumes/'.png", { x: 20, y: 20 }),
      new Costume("!", "./Text/costumes/!.png", { x: 20, y: 20 }),
      new Costume("?", "./Text/costumes/?.png", { x: 20, y: 20 }),
      new Costume("Back2", "./Text/costumes/Back2.svg", {
        x: 229.8482109570042,
        y: 19.983745,
      }),
      new Costume("Back1", "./Text/costumes/Back1.svg", {
        x: 229.84821,
        y: 19.983745,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Remove Text" },
        this.whenIReceiveRemoveText
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Start Speaking" },
        this.whenIReceiveStartSpeaking
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(Trigger.BROADCAST, { name: "Outro" }, this.whenIReceiveOutro),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Glitches" },
        this.whenIReceiveGameGlitches
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "END OF GAME" },
        this.whenIReceiveEndOfGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Loading" },
        this.whenIReceiveLoading
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Scrolling Text" },
        this.whenIReceiveScrollingText
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Scroll Text" },
        this.whenIReceiveScrollText
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Stop Speaking" },
        this.whenIReceiveStopSpeaking
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Render Setting Text" },
        this.whenIReceiveRenderSettingText
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Settings" },
        this.whenIReceiveHideSettings
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.i = 23;
    this.vars.line = "I'LL TURN THE ARROW ON.";
    this.vars.j = 1;
    this.vars.linelength = 644;
    this.vars.fade = "FALSE";
    this.vars.costumetype = "Back";
    this.vars.speechIndex = 4;
    this.vars.winners2 =
      "COLINMACC, A_WISCONSIN_COW, 12HRHT, NIC_4567, MANDACITY.";
    this.vars.ucLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    this.vars.ucOutput = "COLINMACC";
    this.vars.ucL1 = 9;
    this.vars.ucL2 = 3;
    this.vars.zpOutput = 25;
    this.vars.swingwarning = "false";
    this.vars.lines = ["I'LL TURN THE ARROW ON."];
    this.vars.speechText = [
      "OH THAT DIDN'T SOUND GOOD.",
      "WHERE IS MY SIGN?",
      "YOU'D BETTER GO AND#FIND MY SIGN!",
      "I'LL TURN THE ARROW ON.",
    ];
    this.vars.speechDuration = [2, 1, 2, 1];
    this.vars.speechInterval = [1.5, 1, 1, 0.5];
    this.vars.winners = [
      "COLINMACC",
      "A_WISCONSIN_COW",
      "12HRHT",
      "NIC_4567",
      "MANDACITY",
    ];
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.vars.swingwarning = "false";
  }

  *renderTextAtSizeBackgroundFadeType(text, y, s, b, f, typ) {
    this.vars.fade = f;
    if (this.toNumber(typ) === 0) {
      this.vars.costumetype = "Letter";
    } else {
      this.vars.costumetype = typ;
    }
    this.effects.clear();
    this.vars.lines = [];
    this.vars.line = "";
    this.vars.i = 0;
    for (let i = 0; i < text.length; i++) {
      this.vars.i++;
      if (this.letterOf(text, this.vars.i - 1) === "#") {
        if (!(this.toNumber(this.vars.line) === 0)) {
          this.vars.lines.push(this.vars.line);
          this.vars.line = "";
        }
      } else {
        this.vars.line =
          this.toString(this.vars.line) + this.letterOf(text, this.vars.i - 1);
      }
    }
    if (!(this.toNumber(this.vars.line) === 0)) {
      this.vars.lines.push(this.vars.line);
    }
    this.vars.j = 0;
    this.y = this.toNumber(y);
    for (let i = 0; i < this.vars.lines.length; i++) {
      this.vars.j++;
      this.vars.line = this.itemOf(this.vars.lines, this.vars.j - 1);
      this.vars.linelength = this.vars.line.length * 28;
      this.x = Math.floor(
        ((14 - this.toNumber(this.vars.linelength) / 2) * this.toNumber(s)) /
          100
      );
      this.vars.i = 0;
      for (let i = 0; i < this.vars.line.length; i++) {
        this.vars.i++;
        if (
          !(this.toNumber(this.letterOf(this.vars.line, this.vars.i - 1)) === 0)
        ) {
          this.costume = "?";
          this.size = this.toNumber(s);
          this.costume = this.letterOf(this.vars.line, this.vars.i - 1);
          this.createClone();
        }
        this.x += (28 * this.toNumber(s)) / 100;
      }
      this.y += (-28 * this.toNumber(s)) / 100;
    }
    if (this.toString(b) === "TRUE") {
      this.goto(0, this.toNumber(y) - 8);
      this.size = 100;
      this.costume = "Back" + this.toString(this.vars.lines.length);
      this.effects.ghost = 75;
      this.vars.costumetype = "Back";
      this.createClone();
    }
  }

  *whenIReceiveRemoveText() {
    yield* this.deleteText();
  }

  *deleteText() {
    if (
      this.toString(this.vars.instance) === "CLONE" &&
      !(this.toString(this.vars.costumetype) === "SETTINGS")
    ) {
      if (this.toString(this.vars.fade) === "TRUE") {
        for (let i = 0; i < 20; i++) {
          this.effects.ghost += 5;
          yield;
        }
      }
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.moveAhead();
    if (
      this.toString(this.vars.fade) === "TRUE" &&
      this.toString(this.vars.costumetype) === "Letter"
    ) {
      this.effects.ghost = 100;
      this.visible = true;
      for (let i = 0; i < 20; i++) {
        this.effects.ghost -= 5;
        yield;
      }
    } else {
      this.visible = true;
    }
  }

  *whenIReceiveStartSpeaking() {
    if (this.toString(this.vars.instance) === "BASE") {
      /* TODO: Implement stop other scripts in sprite */ null;
      this.broadcast("Stop Speech");
      yield* this.broadcastAndWait("Remove Text");
      yield* this.loadSpeeches();
      this.vars.speechIndex = 0;
      for (let i = 0; i < this.vars.speechText.length; i++) {
        this.vars.speechIndex++;
        yield* this.wait(
          this.toNumber(
            this.itemOf(this.vars.speechInterval, this.vars.speechIndex - 1)
          )
        );
        while (!!(this.toString(this.stage.vars.Scrolling) === "TRUE")) {
          yield;
        }
        yield* this.renderTextAtSizeBackgroundFadeType(
          this.itemOf(this.vars.speechText, this.vars.speechIndex - 1),
          120,
          50,
          "TRUE",
          "FALSE",
          0
        );
        this.broadcast("Speak");
        yield* this.wait(
          this.toNumber(
            this.itemOf(this.vars.speechDuration, this.vars.speechIndex - 1)
          )
        );
        yield* this.broadcastAndWait("Remove Text");
        yield;
      }
      if (this.toNumber(this.stage.vars.Speech) === 1) {
        this.vars.swingwarning = "true";
      }
      if (this.toString(this.stage.vars.Speech) === "GF") {
        this.broadcast("Normal Speech");
      }
      if (this.toString(this.stage.vars.Speech) === "G3") {
        this.broadcast("Open Gate");
      }
      if (this.toNumber(this.stage.vars.Speech) === 11) {
        this.stage.vars.Achievementcode = "GOAT";
        this.broadcast("Unlock Achievement");
        this.broadcast("Click Guard Off");
      }
      if (this.toNumber(this.stage.vars.Speech) === 31) {
        yield* this.wait(1);
        this.broadcast("Escape");
      }
    }
  }

  *loadSpeeches() {
    this.vars.speechText = [];
    this.vars.speechDuration = [];
    this.vars.speechInterval = [];
    if (this.toNumber(this.stage.vars.Speech) === 1) {
      this.warp(this.loadSpeechDurationInterval)("OH. IT'S YOU AGAIN.", 2, 0);
      this.warp(this.loadSpeechDurationInterval)(
        "I SEE YOU CAME BACK!",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "WELL AS YOU CAN SEE,#THIS GAME IS NOW BROKEN.",
        4,
        1
      );
      this.warp(this.loadSpeechDurationInterval)("IT'S OUT OF ORDER.", 2, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "I TRY TO FIX IT, BUT NO LUCK.",
        2,
        2
      );
      this.warp(this.loadSpeechDurationInterval)(
        "SO, YOU SHOULD JUST LEAVE NOW.",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "BECAUSE THERE'S NOTHING TO DO#HERE.",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)("SO THAT'S IT.", 1, 2);
      this.warp(this.loadSpeechDurationInterval)("TAKE CARE NOW.", 1, 2);
      this.warp(this.loadSpeechDurationInterval)(
        "ANYWAY, DO YOU LIKE MY SIGN?",
        2,
        5
      );
      this.warp(this.loadSpeechDurationInterval)("I MADE IT MYSELF.", 1, 2);
      this.warp(this.loadSpeechDurationInterval)(
        "SO PLEASE DO NOT SWING ON IT.",
        2,
        2
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I DON'T THINK IT'S STRONG ENOUGH#TO DO THAT.",
        3,
        2
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 2) {
      this.warp(this.loadSpeechDurationInterval)(
        "OH NO! LOOK WHAT YOU DID!",
        2,
        0
      );
      this.warp(this.loadSpeechDurationInterval)("PICK IT UP PLEASE!", 1, 1);
      this.warp(this.loadSpeechDurationInterval)("COME ON!", 1, 0.5);
      if (this.toString(this.vars.swingwarning) === "TRUE") {
        this.warp(this.loadSpeechDurationInterval)(
          "I TOLD YOU NOT TO SWING ON IT!",
          2,
          1
        );
      }
    }
    if (this.toNumber(this.stage.vars.Speech) === 3) {
      this.warp(this.loadSpeechDurationInterval)("NO! PICK IT UP!", 2, 0);
    }
    if (this.toNumber(this.stage.vars.Speech) === 4) {
      this.warp(this.loadSpeechDurationInterval)(
        "IS IT TOO HEAVY TO LIFT?",
        2,
        0
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 5) {
      this.warp(this.loadSpeechDurationInterval)(
        "YOU'RE GOING TO BREAK IT!",
        2,
        0
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 6) {
      this.warp(this.loadSpeechDurationInterval)(
        "PLEASE STOP ALL THIS BANGING!",
        2,
        0
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 7) {
      this.warp(this.loadSpeechDurationInterval)("STOP! STOP! STOP!", 2, 0);
    }
    if (this.toNumber(this.stage.vars.Speech) === 8) {
      this.warp(this.loadSpeechDurationInterval)("WHAT HAVE YOU DONE?", 1, 0.5);
      this.warp(this.loadSpeechDurationInterval)(
        "IS THAT THE SETTINGS BUTTON?",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)("OK LET ME THINK.", 2, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "I THINK IT CAN STILL BE FIXED.",
        2,
        1.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "MAYBE SOMETHING IN#THE SETTINGS CAN HELP.",
        3,
        2
      );
    }
    if (this.toString(this.stage.vars.Speech) === "RR") {
      this.warp(this.loadSpeechDurationInterval)(
        "I DON'T THINK WE NEED THAT!",
        2,
        0
      );
    }
    if (this.toString(this.stage.vars.Speech) === "GF") {
      this.warp(this.loadSpeechDurationInterval)(
        "HELLO FELLOW SCRATCHERS!",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)("THIS IS GRIFFPATCH.", 2, 0);
    }
    if (this.toString(this.stage.vars.Speech) === "G2") {
      this.warp(this.loadSpeechDurationInterval)(
        "NO! GRIFFPATCH CANNOT HELP US.",
        2.5,
        1
      );
      if (this.compare(this.stage.vars.Progress, 16) < 0) {
        this.warp(this.loadSpeechDurationInterval)(
          "NOT JUST YET ANYWAY.",
          2,
          1
        );
      }
    }
    if (this.toString(this.stage.vars.Speech) === "G3") {
      this.warp(this.loadSpeechDurationInterval)(
        "HELLO FELLOW SCRATCHERS!",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)("THIS IS GRIFFPATCH.", 2, 0);
      this.warp(this.loadSpeechDurationInterval)(
        "LET ME GIVE YOU A CLUE.",
        1,
        0
      );
      this.warp(this.loadSpeechDurationInterval)(
        "TIME FOR SOME REAL FUN!",
        2,
        1
      );
    }
    if (this.toString(this.stage.vars.Speech) === "G4") {
      this.warp(this.loadSpeechDurationInterval)(
        "WOAH! WHAT JUST HAPPENED?",
        2.5,
        1
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 9) {
      this.warp(this.loadSpeechDurationInterval)("WHAT HAVE YOU DONE?", 1, 0);
    }
    if (this.toNumber(this.stage.vars.Speech) === 10) {
      this.warp(this.loadSpeechDurationInterval)(
        "HEY! THIS MIGHT ACTUALLY WORK!",
        2,
        0
      );
      this.warp(this.loadSpeechDurationInterval)(
        "OH NO! WHERE'S IT GOING?",
        2,
        1.5
      );
      this.warp(this.loadSpeechDurationInterval)("COME BACK!", 1, 0.5);
    }
    if (this.toNumber(this.stage.vars.Speech) === 11) {
      this.warp(this.loadSpeechDurationInterval)(
        "OH THAT DIDN'T SOUND GOOD.",
        2,
        1.5
      );
      this.warp(this.loadSpeechDurationInterval)("WHERE IS MY SIGN?", 1, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "YOU'D BETTER GO AND#FIND MY SIGN!",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I'LL TURN THE ARROW ON.",
        1,
        0.5
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 12) {
      this.warp(this.loadSpeechDurationInterval)("THERE IT IS!", 1.5, 0.5);
      this.warp(this.loadSpeechDurationInterval)(
        "OH IT'S COMPLETELY RUINED!",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "GREAT JOB, EINSTEIN.",
        1.5,
        2
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I DIDN'T WANT YOU TO SEE THIS.",
        2,
        2
      );
      this.warp(this.loadSpeechDurationInterval)(
        "IT'S SUCH A MESS IN HERE!",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "LOOK AT THE STATE OF MY TREE!",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "AND ALL THESE FLIES.#WHERE DID THEY COME FROM?",
        3,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "WE NEED TO GET RID OF THEM.",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "DO YOU KNOW ANY ANIMALS#THAT EAT FLIES?",
        3,
        3
      );
      this.warp(this.loadSpeechDurationInterval)(
        "PERHAPS YOU CAN MAKE ONE APPEAR.",
        2,
        2
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 13) {
      this.warp(this.loadSpeechDurationInterval)("IT'S A FROG!", 1.5, 1.5);
      this.warp(this.loadSpeechDurationInterval)("DO FROGS EAT FLIES?", 2, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "I DON'T KNOW THE ANSWER.",
        1,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "PERHAPS HE NEEDS SOME#ENCOURAGEMENT?",
        3,
        4
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 14) {
      this.warp(this.loadSpeechDurationInterval)("THAT'S IT!", 1, 0.5);
      this.warp(this.loadSpeechDurationInterval)(
        "LOOKS LIKE FROGGY IS HUNGRY!",
        2,
        1
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 15) {
      this.warp(this.loadSpeechDurationInterval)("OH LOOK AT THAT!", 1.5, 0);
      this.warp(this.loadSpeechDurationInterval)(
        "THAT FLY IS CARRYING ANOTHER#LETTER!",
        2,
        0.5
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 16) {
      this.warp(this.loadSpeechDurationInterval)("YOU GOT THE LETTER!", 1, 0);
      this.warp(this.loadSpeechDurationInterval)(
        "SO WHAT USE IS THE#LETTER Z?",
        3,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)("I CAN'T THINK.", 1, 2);
      this.warp(this.loadSpeechDurationInterval)(
        "OH BY THE WAY.#DID I MENTION I LIKE PUZZLES?",
        4,
        5
      );
      this.warp(this.loadSpeechDurationInterval)("ESPECIALLY MAZES.", 2, 3);
    }
    if (this.toNumber(this.stage.vars.Speech) === 17) {
      this.warp(this.loadSpeechDurationInterval)(
        "WHY DO YOU LIKE DESTROYING#MY THINGS?",
        3,
        0.5
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 18) {
      this.warp(this.loadSpeechDurationInterval)(
        "OH NO! WHAT HAVE YOU DONE?",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "YOU'VE LET THE GLITCHES ESCAPE!",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "THIS IS JUST THE WORST!",
        2,
        1
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 19) {
      this.warp(this.loadSpeechDurationInterval)(
        "YOU'VE CAUGHT THEM ALL!",
        1.5,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "THEY ARE SAFE IN THE BOX NOW.",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "WELL DONE!#PERHAPS I MISJUDGED YOU.",
        3,
        1
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 20) {
      this.warp(this.loadSpeechDurationInterval)("IT'S WORKING!", 1, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "IT'S PULLING IN#ALL THE GLITCHES!",
        2,
        3
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 21) {
      this.warp(this.loadSpeechDurationInterval)("OUCH! THAT'S HOT!", 1.5, 0);
      this.warp(this.loadSpeechDurationInterval)(
        "YOU CAN'T PICK UP FIRE#IN YOUR BARE HANDS.",
        2.5,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "MAYBE YOU NEED TO FIND SOMETHING#THAT BURNS.",
        3,
        4
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 24) {
      this.warp(this.loadSpeechDurationInterval)("IT'S MY MAZE!", 1.5, 0.5);
      this.warp(this.loadSpeechDurationInterval)(
        "BUT WHAT IS THAT FIRE#DOING THERE?",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I BET IT'S SOMETHING TO DO#WITH THE GOAT.",
        2,
        0.5
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 25) {
      this.warp(this.loadSpeechDurationInterval)("WHAT IS THIS?", 2, 0.5);
      this.warp(this.loadSpeechDurationInterval)("THIS LOOKS DANGEROUS!", 2, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "I'D STAY AWAY IF I WERE YOU!",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I'D DEFINITELY KEEP FIRE#AWAY FROM THIS ROOM!",
        3,
        3
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 26) {
      this.warp(this.loadSpeechDurationInterval)(
        "OH THIS IS INTERESTING!",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "YOU MUST FIND A WAY#TO TURN IT ON.",
        2,
        2
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 27) {
      this.warp(this.loadSpeechDurationInterval)(
        "HEY DON'T TOUCH THINGS IN HERE!",
        2.5,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "THESE THINGS ARE NEEDED#FOR THE OTHER GAME.",
        2.5,
        1
      );
      this.warp(this.loadSpeechDurationInterval)("UH .. THE NON GAME.", 2, 0.5);
    }
    if (this.toNumber(this.stage.vars.Speech) === 28) {
      this.warp(this.loadSpeechDurationInterval)(
        "THIS IS NOT HEAVY ENOUGH.",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "IS THERE ANY WAY YOU CAN...#MAKE IT HEAVIER?",
        3,
        1
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 29) {
      this.warp(this.loadSpeechDurationInterval)(
        "THIS IS NOT HEAVY ENOUGH.",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "CAN YOU FIND ANYTHING HEAVIER?",
        2,
        1
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 30) {
      this.warp(this.loadSpeechDurationInterval)(
        "IT'S THE GOAT!#HE'S FOUND A WAY OUT!",
        3,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "YOU NEED TO UNLOCK IT. HURRY!",
        2,
        2
      );
    }
    if (this.toNumber(this.stage.vars.Speech) === 31) {
      this.warp(this.loadSpeechDurationInterval)(
        "YOU DID IT! YOU SET US FREE!",
        2,
        0.5
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I CAN NEVER THANK YOU ENOUGH.",
        2,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "I CAN FINALLY ESCAPE#FROM THIS GLITCH PROJECT.",
        4,
        1
      );
      this.warp(this.loadSpeechDurationInterval)(
        "NOW WE WILL FLY AWAY AND#LIVE HAPPILY EVER AFTER.",
        4,
        1
      );
      this.warp(this.loadSpeechDurationInterval)("THANK YOU, MY FRIEND.", 2, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "UMMM ... LIVE LONG.#AND PROSPER.",
        3,
        1
      );
      this.warp(this.loadSpeechDurationInterval)("GOODBYE NOW. ", 1, 1);
      this.warp(this.loadSpeechDurationInterval)(
        "HEY GOAT! COME ON, LET'S GO!",
        2,
        2
      );
    }
  }

  *loadSpeechDurationInterval(text, duration, interval) {
    this.vars.speechText.push(text);
    this.vars.speechDuration.push(duration);
    this.vars.speechInterval.push(interval);
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.x += 2;
  }

  *whenIReceiveImpact() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.wobble();
    }
  }

  *whenIReceiveOutro() {
    if (this.toString(this.vars.instance) === "BASE") {
      yield* this.broadcastAndWait("Remove Text");
      this.stage.vars.Completed++;
      yield* this.wait(0.1);
      this.stage.vars.Time = this.timer;
      if (this.compare(this.stage.vars.Time, this.stage.vars.FastestTime) < 0) {
        this.stage.vars.FastestTime = this.stage.vars.Time;
        yield* this.wait(0.1);
      }
      yield* this.decodeWinners();
      yield* this.addNameToWinners(/* no username */ "");
      yield* this.wait(1);
      yield* this.renderTextAtSizeBackgroundFadeType(
        "GAME OVER",
        0,
        120,
        "FALSE",
        "TRUE",
        0
      );
      yield* this.wait(5);
      yield* this.renderTextAtSizeBackgroundFadeType(
        "          ?",
        0,
        120,
        "FALSE",
        "TRUE",
        0
      );
      yield* this.wait(2);
      yield* this.titleFade();
    }
  }

  *titleFade() {
    yield* this.wait(2);
    yield* this.broadcastAndWait("Remove Text");
    yield* this.wait(1);
  }

  *whenIReceiveGameGlitches() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.wobble();
    }
  }

  *whenIReceiveEndOfGame() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.wobble();
    }
  }

  *whenIReceiveLoading() {
    if (this.toString(this.vars.instance) === "BASE") {
      yield* this.broadcastAndWait("Remove Text");
      yield* this.renderTextAtSizeBackgroundFadeType(
        "NOT LOADING",
        20,
        40,
        "FALSE",
        "FALSE",
        0
      );
      yield* this.broadcastAndWait("Gauge");
      yield* this.titleFade();
    }
  }

  *whenIReceiveScrollingText() {
    this.size = 400;
    this.goto(250, -160);
    this.size = 75;
    yield* this.decodeWinners();
    this.stage.vars.ScrollingMessage =
      "YOU COMPLETED THIS GAME IN " +
      (this.toString(Math.floor(this.toNumber(this.stage.vars.Time) / 60)) +
        (" MINUTES " +
          this.toString(
            Math.floor(
              this.toNumber(this.stage.vars.Time) -
                Math.floor(this.toNumber(this.stage.vars.Time) / 60) * 60
            )
          )) +
        " SECONDS. ");
    this.stage.vars.ScrollingMessage =
      this.toString(this.stage.vars.ScrollingMessage) +
      ("THIS GAME HAS BEEN COMPLETED " +
        (this.toString(this.stage.vars.Completed) + " TIMES. "));
    this.stage.vars.ScrollingMessage =
      this.toString(this.stage.vars.ScrollingMessage) +
      ("THE LAST " +
        (this.toString(this.vars.winners.length) +
          (" WINNERS WERE " + this.toString(this.vars.winners2))));
    this.stage.vars.ScrollingMessage =
      this.toString(this.stage.vars.ScrollingMessage) +
      " THIS GAME WAS INSPIRED BY THERE IS NO GAME BY KAMIZOTO. THE FROG MINI-GAME CONCEPT WAS INSPIRED BY ROKCODER.";
    this.stage.vars.ScrollingMessage =
      this.toString(this.stage.vars.ScrollingMessage) +
      " MOST GRAPHICS, SOUNDS AND MUSIC BY KAMIZOTO. OTHER GRAPHICS FOUND IN STOCK IMAGES ON GOOGLE OR MADE BY ME.";
    this.stage.vars.ScrollingMessage =
      this.toString(this.stage.vars.ScrollingMessage) +
      " GLITCH SONG BY TAYLOR SWIFT. NEVER GONNA GIVE YOU UP SONG BY RICK ASTLEY. GRIFFPATCH VOICE BY GRIFFPATCH. THE OTHER VOICE ACTING IS BY ME. THANK YOU FOR PLAYING!";
    this.vars.costumetype = "Scrolling";
    this.vars.i = 0;
    this.vars.j = 0;
    while (true) {
      this.vars.j++;
      if (this.toNumber(this.vars.j) % 4 === 0) {
        this.vars.i++;
        if (
          !(
            this.compare(this.vars.i, this.stage.vars.ScrollingMessage.length) >
            0
          )
        ) {
          if (
            !(
              this.toNumber(
                this.letterOf(this.stage.vars.ScrollingMessage, this.vars.i - 1)
              ) === 0
            )
          ) {
            this.costume = this.letterOf(
              this.stage.vars.ScrollingMessage,
              this.vars.i - 1
            );
            this.createClone();
          }
        }
        if (
          this.compare(
            this.vars.i,
            this.stage.vars.ScrollingMessage.length + 24
          ) > 0
        ) {
          this.vars.i = 0;
        }
      }
      this.broadcast("Scroll Text");
      yield* this.wait(0.05);
      yield;
    }
  }

  *whenIReceiveScrollText() {
    if (this.toString(this.vars.instance) === "CLONE") {
      if (this.toString(this.vars.costumetype) === "Scrolling") {
        if (this.compare(this.x, -235) < 0) {
          this.stage.vars.Clonecount--;
          this.deleteThisClone();
        }
        this.x += (-7 * 75) / 100;
      }
    }
  }

  *decodeWinners() {
    this.vars.winners = [];
    this.vars.winners2 = this.stage.vars.WinnersList;
    this.vars.line = "";
    this.vars.i = 1;
    for (let i = 0; i < Math.floor(this.vars.winners2.length / 2); i++) {
      if (
        this.toNumber(
          this.letterOf(this.vars.winners2, this.vars.i - 1) +
            this.letterOf(this.vars.winners2, this.toNumber(this.vars.i))
        ) === 99
      ) {
        this.vars.winners.push(this.vars.line);
        this.vars.line = "";
      } else {
        this.costume = "Back1";
        this.costume =
          this.letterOf(this.vars.winners2, this.vars.i - 1) +
          this.letterOf(this.vars.winners2, this.toNumber(this.vars.i));
        if (!(this.costume.name === "Back1")) {
          this.vars.line = this.toString(this.vars.line) + this.costume.name;
        }
      }
      this.vars.i += 2;
    }
    if (!(this.toNumber(this.vars.line) === 0)) {
      this.vars.winners.push(this.vars.line);
    }
    this.vars.winners2 = "";
    this.vars.i = 0;
    for (let i = 0; i < this.vars.winners.length; i++) {
      this.vars.i++;
      if (this.toNumber(this.vars.i) === 1) {
        this.vars.winners2 = this.itemOf(this.vars.winners, this.vars.i - 1);
      } else {
        this.vars.winners2 =
          this.toString(this.vars.winners2) +
          (", " +
            this.toString(this.itemOf(this.vars.winners, this.vars.i - 1)));
      }
    }
    this.vars.winners2 = this.toString(this.vars.winners2) + ".";
  }

  *uppercase(str) {
    this.vars.ucLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    this.vars.ucOutput = "";
    this.vars.ucL1 = 0;
    for (let i = 0; i < str.length; i++) {
      this.vars.ucL1++;
      this.vars.ucL2 = 0;
      while (
        !(
          this.compare(
            this.letterOf(this.vars.ucLetters, this.vars.ucL2 - 1),
            this.letterOf(str, this.vars.ucL1 - 1)
          ) === 0 ||
          this.compare(this.vars.ucL2, this.vars.ucLetters.length) > 0
        )
      ) {
        this.vars.ucL2++;
      }
      if (this.compare(this.vars.ucL2, this.vars.ucLetters.length) > 0) {
        this.vars.ucOutput =
          this.toString(this.vars.ucOutput) +
          this.letterOf(str, this.vars.ucL1 - 1);
      } else {
        this.vars.ucOutput =
          this.toString(this.vars.ucOutput) +
          this.letterOf(this.vars.ucLetters, this.vars.ucL2 - 1);
      }
    }
  }

  *addNameToWinners(name) {
    this.warp(this.uppercase)(name);
    if (this.arrayIncludes(this.vars.winners, this.vars.ucOutput)) {
      this.vars.winners.splice(
        this.indexInArray(this.vars.winners, this.vars.ucOutput),
        1
      );
    }
    this.vars.winners.splice(0, 0, this.vars.ucOutput);
    if (this.compare(this.vars.winners.length, 5) > 0) {
      this.vars.winners.splice(this.vars.winners.length - 1, 1);
    }
    this.vars.winners2 = "";
    this.vars.i = 0;
    for (let i = 0; i < this.vars.winners.length; i++) {
      this.vars.i++;
      this.vars.line = this.itemOf(this.vars.winners, this.vars.i - 1);
      this.vars.j = 0;
      for (let i = 0; i < this.vars.line.length; i++) {
        this.vars.j++;
        this.costume = "Back1";
        this.costume = this.letterOf(this.vars.line, this.vars.j - 1);
        if (this.costume.name === "Back1") {
          this.vars.winners2 = this.toString(this.vars.winners2) + "00";
        } else {
          this.warp(this.zeropad)(this.costumeNumber, 2);
          this.vars.winners2 =
            this.toString(this.vars.winners2) +
            this.toString(this.vars.zpOutput);
        }
      }
      this.vars.winners2 = this.toString(this.vars.winners2) + "99";
    }
    this.stage.vars.WinnersList = this.vars.winners2;
  }

  *zeropad(var2, digits) {
    this.vars.zpOutput = var2;
    for (let i = 0; i < this.toNumber(digits) - var2.length; i++) {
      this.vars.zpOutput = "0" + this.toString(this.vars.zpOutput);
    }
  }

  *resetCloud() {
    this.stage.vars.Completed = 0;
    this.stage.vars.WinnersList = 0;
    this.stage.vars.FastestTime = 999999999999;
  }

  *whenIReceiveStopSpeaking() {
    if (this.toString(this.vars.instance) === "BASE") {
      /* TODO: Implement stop other scripts in sprite */ null;
      this.broadcast("Stop Speech");
      yield* this.broadcastAndWait("Remove Text");
    }
  }

  *whenIReceiveRenderSettingText() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.broadcast("Remove Text");
      yield* this.renderTextAtSizeBackgroundFadeType(
        "SETTINGS",
        70,
        80,
        "N",
        "N",
        "SETTINGS"
      );
      yield* this.renderTextAtSizeBackgroundFadeType(
        "VOICE",
        40,
        60,
        "N",
        "N",
        "SETTINGS"
      );
      yield* this.renderTextAtSizeBackgroundFadeType(
        "    NORMAL      GRIFFPATCH",
        15,
        40,
        "N",
        "N",
        "SETTINGS"
      );
      yield* this.renderTextAtSizeBackgroundFadeType(
        "MUSIC",
        -30,
        60,
        "N",
        "N",
        "SETTINGS"
      );
      yield* this.renderTextAtSizeBackgroundFadeType(
        "OFF      ON ",
        -55,
        40,
        "N",
        "N",
        "SETTINGS"
      );
      yield* this.renderTextAtSizeBackgroundFadeType(
        "WATER",
        -100,
        60,
        "N",
        "N",
        "SETTINGS"
      );
      yield* this.renderTextAtSizeBackgroundFadeType(
        "OFF      ON ",
        -125,
        40,
        "N",
        "N",
        "SETTINGS"
      );
    }
  }

  *whenIReceiveHideSettings() {
    if (!(this.toString(this.vars.instance) === "BASE")) {
      if (this.toString(this.vars.costumetype) === "SETTINGS") {
        this.stage.vars.Clonecount--;
        this.deleteThisClone();
      }
    }
  }
}
