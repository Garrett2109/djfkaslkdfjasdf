/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Frog extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Frog", "./Frog/costumes/Frog.png", { x: 82, y: 74 }),
      new Costume("Frog2", "./Frog/costumes/Frog2.png", { x: 82, y: 74 }),
    ];

    this.sounds = [
      new Sound("SpawnTree", "./Frog/sounds/SpawnTree.mp3"),
      new Sound("Croak", "./Frog/sounds/Croak.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Unlock Achievement" },
        this.whenIReceiveUnlockAchievement
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Animate Frog" },
        this.whenIReceiveAnimateFrog
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Reset Frog" },
        this.whenIReceiveResetFrog
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Animate Frog" },
        this.whenIReceiveAnimateFrog2
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];

    this.vars.unlocked = "FALSE";
    this.vars.x = -80;
    this.vars.y = -155;
  }

  *whenGreenFlagClicked() {
    this.costume = "Frog2";
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.x = -80;
    this.vars.y = -155;
    this.vars.unlocked = "FALSE";
    yield* this.position();
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0 &&
      this.toString(this.vars.unlocked) === "TRUE"
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveUnlockAchievement() {
    if (this.toString(this.stage.vars.Achievementcode) === "FROG") {
      this.stage.vars.Progress++;
      this.vars.unlocked = "TRUE";
      yield* this.startSound("SpawnTree");
      yield* this.wait(1);
      this.stage.vars.sparksx.push(this.x);
      this.stage.vars.sparksy.push(this.y);
      this.stage.vars.sparkstype.push("leaf");
      yield* this.position();
      this.broadcast("Animate Frog");
    }
  }

  *whenIReceiveAnimateFrog() {
    while (true) {
      yield* this.wait(3);
      if (
        this.toNumber(this.stage.vars.Scrollx) === 0 &&
        !(this.touching("mouse") && this.mouse.down)
      ) {
        this.costume = "Frog";
        yield* this.startSound("Croak");
        yield* this.wait(0.3);
        this.costume = "Frog2";
      }
      yield;
    }
  }

  *whenIReceiveResetFrog() {
    this.costume = "Frog2";
  }

  *whenIReceiveAnimateFrog2() {
    while (true) {
      while (
        !(
          this.toNumber(this.stage.vars.Scrollx) === 0 &&
          this.touching("mouse") &&
          this.mouse.down &&
          this.toString(this.stage.vars.RetractTongue) === "false"
        )
      ) {
        yield;
      }
      this.costume = "Frog";
      this.broadcast("Tongue");
      while (
        !!(
          this.touching("mouse") &&
          this.mouse.down &&
          this.toString(this.stage.vars.RetractTongue) === "false"
        )
      ) {
        yield;
      }
      if (
        this.toString(this.stage.vars.RetractTongue) === "false" &&
        !(this.sprites["Tongue"].costumeNumber === 1)
      ) {
        this.stage.vars.RetractTongue = "true";
      } else {
        while (!!(this.touching("mouse") && this.mouse.down)) {
          yield;
        }
      }
      if (this.compare(this.stage.vars.Progress, 15) > 0) {
        return;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.toNumber(this.stage.vars.Progress) === 16) {
      if (this.toString(this.stage.vars.Froghint) === "FALSE") {
        this.stage.vars.Froghint = "TRUE";
        this.broadcast("Frog Hint");
      }
    }
  }
}
